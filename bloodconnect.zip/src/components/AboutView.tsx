import React from 'react';
import { Droplet, Heart, ShieldCheck, Activity, Award, BookOpen, Check } from 'lucide-react';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800">
          <span>🔬 Medical Science & Humanitarian Lifeline</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
          About the BloodConnect Platform
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          Bridging the critical 30-minute logistical gap in emergency transfusions through technological precision, transparent donor matching, and absolute privacy safeguards.
        </p>
      </div>

      {/* Core Mission Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-2xl font-bold">
            🩸
          </div>
          <h3 className="text-lg font-bold text-slate-900">Zero Commercialization</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            BloodConnect operates strictly on a voluntary, non-remunerated donation paradigm in compliance with national and WHO guidelines. Blood is a humanitarian gift, never a commodity.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl font-bold">
            🛡️
          </div>
          <h3 className="text-lg font-bold text-slate-900">Donor Privacy Shield</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Residential street addresses are encrypted and blocked from public web views via Spring Security and Jackson <code>@JsonIgnore</code> policies. Phone numbers are protected against mass scraping.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl font-bold">
            ⚡
          </div>
          <h3 className="text-lg font-bold text-slate-900">Relational Precision</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Built atop MySQL 8 and Spring Data JPA with transactional consistency (ACID). Every blood request state transition from PENDING to FULFILLED is audited with timestamps and foreign-key integrity.
          </p>
        </div>
      </div>

      {/* Blood Compatibility Guide */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-sm space-y-6">
        <div>
          <span className="text-xs font-bold text-rose-600 uppercase tracking-widest">Biological Foundations</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Comprehensive Blood Group Compatibility
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl">
            Red blood cells possess antigens (A, B, and Rh factor). Transfusing incompatible red cells triggers lethal agglutination. Our matching algorithm automatically verifies biological safety.
          </p>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-rose-50/75 border-b border-rose-100 text-rose-950 font-extrabold">
                <th className="p-3.5">Blood Type</th>
                <th className="p-3.5">Antigens Present</th>
                <th className="p-3.5">Can Safely Give To (Donates To)</th>
                <th className="p-3.5">Can Safely Receive From</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">A+</td>
                <td className="p-3.5 text-slate-600">A, Rh</td>
                <td className="p-3.5 font-semibold text-slate-800">A+, AB+</td>
                <td className="p-3.5 text-slate-600">A+, A-, O+, O-</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">A-</td>
                <td className="p-3.5 text-slate-600">A only</td>
                <td className="p-3.5 font-semibold text-slate-800">A+, A-, AB+, AB-</td>
                <td className="p-3.5 text-slate-600">A-, O-</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">B+</td>
                <td className="p-3.5 text-slate-600">B, Rh</td>
                <td className="p-3.5 font-semibold text-slate-800">B+, AB+</td>
                <td className="p-3.5 text-slate-600">B+, B-, O+, O-</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">B-</td>
                <td className="p-3.5 text-slate-600">B only</td>
                <td className="p-3.5 font-semibold text-slate-800">B+, B-, AB+, AB-</td>
                <td className="p-3.5 text-slate-600">B-, O-</td>
              </tr>
              <tr className="bg-rose-50/40 hover:bg-rose-50/70 font-semibold">
                <td className="p-3.5 font-extrabold text-rose-800">AB+ (Universal Recipient)</td>
                <td className="p-3.5 text-slate-600">A, B, Rh</td>
                <td className="p-3.5 text-slate-800">AB+ only</td>
                <td className="p-3.5 font-bold text-emerald-700">All Blood Types (A+, A-, B+, B-, AB+, AB-, O+, O-)</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">AB-</td>
                <td className="p-3.5 text-slate-600">A, B only</td>
                <td className="p-3.5 font-semibold text-slate-800">AB+, AB-</td>
                <td className="p-3.5 text-slate-600">AB-, A-, B-, O-</td>
              </tr>
              <tr className="hover:bg-slate-50">
                <td className="p-3.5 font-extrabold text-rose-700">O+</td>
                <td className="p-3.5 text-slate-600">Rh only</td>
                <td className="p-3.5 font-semibold text-slate-800">O+, A+, B+, AB+</td>
                <td className="p-3.5 text-slate-600">O+, O-</td>
              </tr>
              <tr className="bg-red-50/60 hover:bg-red-50/90 font-semibold">
                <td className="p-3.5 font-extrabold text-red-800">O- (Universal Red Cell Donor)</td>
                <td className="p-3.5 text-slate-600">None</td>
                <td className="p-3.5 font-bold text-red-700">All Blood Types (Universal Red Cell Donor)</td>
                <td className="p-3.5 text-slate-800">O- only</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Safety & Eligibility Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
            <Award className="w-5 h-5 text-rose-600" /> Who Can Safely Donate?
          </h3>
          <ul className="text-xs text-slate-600 space-y-2">
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Individuals aged 18 to 65 years with good physical health.</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Body weight above 50 kg (110 pounds) and normal blood pressure.</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Hemoglobin level ≥ 12.5 g/dL measured before collection.</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Interval of at least 90 days (12 weeks) between consecutive whole blood donations.</span>
            </li>
          </ul>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" /> Donor Safety Protocols
          </h3>
          <ul className="text-xs text-slate-600 space-y-2">
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Sterile, single-use disposable needles ensure zero risk of bloodborne infection transmission.</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Plasma volume is replenished naturally within 24 to 48 hours; red cells regenerate within a few weeks.</span>
            </li>
            <li className="flex items-start gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Each donated unit undergoes mandatory laboratory screening for HIV, Hepatitis B & C, Syphilis, and Malaria.</span>
            </li>
          </ul>
        </div>
      </div>

    </div>
  );
};
