import React, { useState } from 'react';
import { BloodRequest, BloodGroupType, UrgencyType } from '../types/bloodconnect';
import { AlertCircle, PlusCircle, CheckCircle2, Clock, MapPin, Building2, Phone, Heart } from 'lucide-react';

interface RequestBloodViewProps {
  existingRequests: BloodRequest[];
  onRequestSubmitted: (newRequest: Omit<BloodRequest, 'id' | 'createdAt' | 'requestStatus'>) => void;
  setActivePage: (page: string) => void;
}

export const RequestBloodView: React.FC<RequestBloodViewProps> = ({
  existingRequests,
  onRequestSubmitted,
  setActivePage
}) => {
  const [patientName, setPatientName] = useState('');
  const [requiredBloodGroup, setRequiredBloodGroup] = useState<BloodGroupType>('O+');
  const [numberOfUnits, setNumberOfUnits] = useState<number>(2);
  const [contactNumber, setContactNumber] = useState('');
  const [hospitalName, setHospitalName] = useState('');
  const [hospitalLocation, setHospitalLocation] = useState('');
  const [urgency, setUrgency] = useState<UrgencyType>('URGENT');
  const [additionalMessage, setAdditionalMessage] = useState('');
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const bloodGroups: BloodGroupType[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientName.trim() || !contactNumber.trim() || !hospitalName.trim() || !hospitalLocation.trim()) {
      alert('Please fill in all mandatory fields.');
      return;
    }

    onRequestSubmitted({
      patientName: patientName.trim(),
      requiredBloodGroup,
      numberOfUnits,
      contactNumber: contactNumber.trim(),
      hospitalName: hospitalName.trim(),
      hospitalLocation: hospitalLocation.trim(),
      urgency,
      additionalMessage: additionalMessage.trim() || undefined
    });

    setSubmittedSuccess(true);
    // Reset fields
    setPatientName('');
    setContactNumber('');
    setHospitalName('');
    setHospitalLocation('');
    setAdditionalMessage('');
    setTimeout(() => setSubmittedSuccess(false), 6000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 animate-pulse">
          <span>🚨 Emergency Request Dispatch</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Request Blood for Patient
        </h1>
        <p className="text-sm text-slate-600">
          Broadcast critical blood requirements to nearby registered voluntary donors. Records are stored in MySQL 8 and prioritized by urgency.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Form Column */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
          {submittedSuccess && (
            <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-3 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <strong className="block text-sm">Blood Request Dispatched Successfully!</strong>
                Compatible donors in the database are being alerted. Your request is now active on the public board.
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Patient Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g. Ramesh Chandra"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Required Blood Group *
                </label>
                <select
                  value={requiredBloodGroup}
                  onChange={(e) => setRequiredBloodGroup(e.target.value as BloodGroupType)}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500 bg-white"
                >
                  {bloodGroups.map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Units Needed (Pints) *
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  required
                  value={numberOfUnits}
                  onChange={(e) => setNumberOfUnits(parseInt(e.target.value, 10))}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Primary Contact Number *
                </label>
                <input
                  type="tel"
                  required
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Hospital / Clinic Name *
                </label>
                <input
                  type="text"
                  required
                  value={hospitalName}
                  onChange={(e) => setHospitalName(e.target.value)}
                  placeholder="e.g. Lilavati Hospital & Research"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Hospital City / Location *
                </label>
                <input
                  type="text"
                  required
                  value={hospitalLocation}
                  onChange={(e) => setHospitalLocation(e.target.value)}
                  placeholder="e.g. Mumbai, Bandra West"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            {/* Urgency Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Clinical Urgency Priority *
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setUrgency('NORMAL')}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    urgency === 'NORMAL'
                      ? 'border-emerald-500 bg-emerald-50/80 text-emerald-900 font-bold ring-1 ring-emerald-400'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="font-bold">Normal</div>
                  <div className="text-[10px] text-slate-500">2-5 Days Ahead</div>
                </button>

                <button
                  type="button"
                  onClick={() => setUrgency('URGENT')}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    urgency === 'URGENT'
                      ? 'border-amber-500 bg-amber-50/80 text-amber-900 font-bold ring-1 ring-amber-400'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="font-bold">Urgent</div>
                  <div className="text-[10px] text-slate-500">Within 24 Hours</div>
                </button>

                <button
                  type="button"
                  onClick={() => setUrgency('EMERGENCY')}
                  className={`p-3 rounded-xl border text-left text-xs transition ${
                    urgency === 'EMERGENCY'
                      ? 'border-red-600 bg-red-50 text-red-900 font-black ring-2 ring-red-500 animate-pulse'
                      : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="font-bold text-red-600">🚨 EMERGENCY</div>
                  <div className="text-[10px] text-slate-500">ICU / Immediate</div>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Additional Clinical Notes or Ward Instructions
              </label>
              <textarea
                rows={3}
                value={additionalMessage}
                onChange={(e) => setAdditionalMessage(e.target.value)}
                placeholder="Mention ward number, doctor in charge, or specific blood component (Whole blood, PRBC, Platelets, FFP)..."
                className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 shadow-md shadow-rose-600/30 transition text-sm flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4" /> Broadcast Blood Request to Database
            </button>
          </form>
        </div>

        {/* Info & Guidelines Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-gradient-to-br from-rose-900 to-slate-900 text-white rounded-2xl p-6 shadow-md space-y-3">
            <h3 className="font-bold text-base flex items-center gap-2 text-rose-300">
              <AlertCircle className="w-5 h-5 text-rose-400" /> Emergency Response SLA
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              When tagged with <strong>EMERGENCY</strong>, our matching engine flags compatible donors within the specified city as priority recipients.
            </p>
            <ul className="text-xs text-slate-300 space-y-1.5 pt-1">
              <li>• Always verify with the attending physician the exact blood component needed.</li>
              <li>• Keep the contact phone line clear for incoming donor coordination.</li>
              <li>• Voluntary donations are completely free of charge.</li>
            </ul>
          </div>

          {/* Recent Blood Requests in System */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                Recent Network Requests ({existingRequests.length})
              </h4>
              <span className="text-[11px] text-slate-400">Live Status</span>
            </div>

            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {existingRequests.slice(0, 5).map((req) => (
                <div key={req.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{req.patientName}</span>
                    <span className="font-extrabold text-rose-600 bg-rose-100 px-2 py-0.5 rounded text-[10px]">
                      {req.requiredBloodGroup} ({req.numberOfUnits} unit)
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px] flex items-center justify-between">
                    <span>{req.hospitalName}, {req.hospitalLocation}</span>
                    <span className={`font-bold ${
                      req.urgency === 'EMERGENCY' ? 'text-red-600' : 'text-slate-600'
                    }`}>
                      {req.urgency}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
