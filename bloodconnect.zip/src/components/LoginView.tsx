import React, { useState } from 'react';
import { User } from '../types/bloodconnect';
import { LogIn, Key, Mail, CheckCircle2, AlertCircle, Shield } from 'lucide-react';

interface LoginViewProps {
  onLoginSuccess: (user: User) => void;
  setActivePage: (page: string) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  setActivePage
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanEmail = email.trim().toLowerCase();

    // Check credentials against demo users
    if (cleanEmail === 'aarav.sharma@example.com' || cleanEmail.includes('aarav')) {
      const donorUser: User = {
        id: 2,
        fullName: 'Aarav Sharma',
        email: 'aarav.sharma@example.com',
        role: 'ROLE_DONOR',
        accountStatus: 'ACTIVE',
        createdAt: '2024-01-10T08:30:00Z'
      };
      onLoginSuccess(donorUser);
      setActivePage('donor-profile');
    } else if (cleanEmail === 'vikram.hospital@example.com' || cleanEmail.includes('vikram')) {
      const requesterUser: User = {
        id: 6,
        fullName: 'Dr. Vikram Malhotra',
        email: 'vikram.hospital@example.com',
        role: 'ROLE_REQUESTER',
        accountStatus: 'ACTIVE',
        createdAt: '2024-02-15T09:00:00Z'
      };
      onLoginSuccess(requesterUser);
      setActivePage('request-blood');
    } else if (cleanEmail === 'admin@bloodconnect.org' || cleanEmail.includes('admin')) {
      const adminUser: User = {
        id: 1,
        fullName: 'System Administrator',
        email: 'admin@bloodconnect.org',
        role: 'ROLE_ADMIN',
        accountStatus: 'ACTIVE',
        createdAt: '2023-01-01T00:00:00Z'
      };
      onLoginSuccess(adminUser);
      setActivePage('find-donor');
    } else {
      // General user login
      const genericUser: User = {
        id: 99,
        fullName: cleanEmail.split('@')[0],
        email: cleanEmail,
        role: 'ROLE_DONOR',
        accountStatus: 'ACTIVE',
        createdAt: new Date().toISOString()
      };
      onLoginSuccess(genericUser);
      setActivePage('donor-profile');
    }
  };

  const fillDemo = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setErrorMessage('');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12 space-y-8">
      
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br from-rose-500 to-rose-700 flex items-center justify-center text-white text-2xl shadow-md shadow-rose-500/25">
          🩸
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Sign In to BloodConnect
        </h1>
        <p className="text-xs text-slate-500">
          Stateless JWT authentication backed by Spring Security & MySQL 8
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        
        {errorMessage && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-9 pr-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Password
            </label>
            <div className="relative">
              <Key className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl font-bold text-white bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 shadow-md shadow-rose-600/30 transition text-sm flex items-center justify-center gap-2"
          >
            <LogIn className="w-4 h-4" /> Sign In
          </button>
        </form>

        {/* 1-Click Demo Logins for Examiner / Testing */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center">
            ⚡ Quick-Fill Demonstration Accounts
          </div>

          <div className="space-y-2">
            <button
              type="button"
              onClick={() => fillDemo('aarav.sharma@example.com', 'Password@123')}
              className="w-full p-2.5 rounded-xl border border-rose-100 bg-rose-50/50 hover:bg-rose-100 text-left transition flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-rose-900 block">👤 Registered Donor (Aarav Sharma)</span>
                <span className="text-[11px] text-slate-500">Blood Group: O+ • Mumbai</span>
              </div>
              <span className="text-rose-600 text-[11px] font-bold">Auto-Fill →</span>
            </button>

            <button
              type="button"
              onClick={() => fillDemo('vikram.hospital@example.com', 'Password@123')}
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-slate-900 block">🏥 Hospital Doctor (Dr. Vikram)</span>
                <span className="text-[11px] text-slate-500">Requester • Lilavati Hospital</span>
              </div>
              <span className="text-slate-600 text-[11px] font-bold">Auto-Fill →</span>
            </button>

            <button
              type="button"
              onClick={() => fillDemo('admin@bloodconnect.org', 'Password@123')}
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-slate-900 block">🛡️ Platform Administrator</span>
                <span className="text-[11px] text-slate-500">Full Access & Database Audit</span>
              </div>
              <span className="text-slate-600 text-[11px] font-bold">Auto-Fill →</span>
            </button>
          </div>
        </div>

        <div className="text-center text-xs text-slate-500">
          New to BloodConnect?{' '}
          <button
            onClick={() => setActivePage('register')}
            className="font-bold text-rose-600 hover:underline"
          >
            Register as a Volunteer Donor
          </button>
        </div>

      </div>

    </div>
  );
};
