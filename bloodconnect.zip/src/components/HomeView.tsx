import React from 'react';
import { PlatformStats, BloodRequest } from '../types/bloodconnect';
import { 
  Search, 
  PlusCircle, 
  ShieldCheck, 
  Activity, 
  Users, 
  HeartHandshake, 
  Clock, 
  MapPin, 
  AlertTriangle,
  ArrowRight,
  Droplet
} from 'lucide-react';

interface HomeViewProps {
  stats: PlatformStats;
  emergencyRequests: BloodRequest[];
  setActivePage: (page: string) => void;
  onSelectRequestForResponse?: (req: BloodRequest) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  stats,
  emergencyRequests,
  setActivePage,
  onSelectRequestForResponse
}) => {
  return (
    <div className="space-y-12 pb-16">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-rose-50/80 via-white to-slate-50 border-b border-rose-100/60 pt-12 pb-16 md:pt-20 md:pb-24">
        {/* Soft decorative background glows */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-rose-200/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-red-100/40 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Headlines & Call to Action */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-rose-100/80 border border-rose-200 text-rose-800 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-xs">
                <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping" />
                <span>Real-Time Database Dispatch Active</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12]">
                Connect Voluntary Donors. <br />
                <span className="bg-gradient-to-r from-rose-600 via-rose-700 to-rose-900 bg-clip-text text-transparent">
                  Save Precious Lives.
                </span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                BloodConnect connects patients requiring urgent transfusions with eligible voluntary blood donors nearby. Powered by an intelligent biological compatibility matching engine and real-time database coordination.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => setActivePage('find-donor')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white font-bold px-7 py-3.5 rounded-xl shadow-lg shadow-rose-600/25 transition transform hover:-translate-y-0.5 text-base"
                >
                  <Search className="w-5 h-5" />
                  <span>Find a Donor Now</span>
                </button>

                <button
                  onClick={() => setActivePage('request-blood')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-white hover:bg-rose-50 text-rose-700 border-2 border-rose-200 font-bold px-7 py-3.5 rounded-xl shadow-xs transition hover:border-rose-400 text-base"
                >
                  <span className="text-rose-600 text-lg">🚨</span>
                  <span>Post Urgent Blood Request</span>
                </button>
              </div>

              {/* Key Trust Signals */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-4 text-xs font-semibold text-slate-500">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Protected Donor Privacy</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-rose-600" />
                  <span>100% Voluntary Non-Remunerated</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-blue-600" />
                  <span>Hospital-Verified Requests</span>
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Hero Blood Card */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-md bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-rose-100">
                
                {/* Floating Blood Drop Graphic */}
                <div className="text-center relative mb-6">
                  <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-rose-500 to-rose-700 p-1 shadow-xl shadow-rose-500/30 flex items-center justify-center animate-pulse-glow">
                    <span className="text-4xl filter drop-shadow">🩸</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mt-4">Every Drop Counts</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                    A single pint of donated blood can be separated into red cells, platelets, and plasma to rescue up to 3 individual patients.
                  </p>
                </div>

                {/* Compatibility Quick Indicator */}
                <div className="bg-rose-50/70 border border-rose-100 rounded-2xl p-4 text-xs space-y-2">
                  <div className="flex justify-between items-center text-rose-900 font-bold">
                    <span>Universal Lifeline Groups</span>
                    <span className="bg-rose-200/70 text-rose-800 px-2 py-0.5 rounded text-[10px]">Medical Fact</span>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded bg-rose-600 text-white font-extrabold flex items-center justify-center text-[10px]">O-</span>
                      <span className="text-slate-700 font-semibold">Universal Red Cell Donor</span>
                    </div>
                    <span className="text-emerald-700 font-bold">Gives to All</span>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-rose-100">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded bg-rose-700 text-white font-extrabold flex items-center justify-center text-[10px]">AB+</span>
                      <span className="text-slate-700 font-semibold">Universal Recipient</span>
                    </div>
                    <span className="text-blue-700 font-bold">Receives from All</span>
                  </div>
                </div>

                {/* Live Match Engine Indicator */}
                <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-semibold text-slate-700">Spring Data JPA / MySQL 8</span>
                  </div>
                  <button 
                    onClick={() => setActivePage('about')}
                    className="text-rose-600 font-bold hover:underline"
                  >
                    Compatibility Matrix →
                  </button>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Database Statistics Counter Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-md">
          <div className="text-center mb-6">
            <span className="text-xs font-extrabold uppercase tracking-widest text-rose-600">
              Database-Backed Metrics
            </span>
            <h3 className="text-lg font-bold text-slate-800">Platform Real-Time Counters</h3>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center divide-y lg:divide-y-0 lg:divide-x divide-slate-100">
            <div className="pt-4 lg:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-rose-600 tracking-tight">
                {stats.registeredDonors.toLocaleString()}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-700 mt-1">Registered Donors</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Verified voluntary donors</div>
            </div>

            <div className="pt-4 lg:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-emerald-600 tracking-tight">
                {stats.availableDonors.toLocaleString()}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-700 mt-1">Available Right Now</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Immediate readiness</div>
            </div>

            <div className="pt-4 lg:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-slate-800 tracking-tight">
                {stats.totalBloodRequests.toLocaleString()}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-700 mt-1">Total Blood Requests</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Logged across hospitals</div>
            </div>

            <div className="pt-4 lg:pt-0">
              <div className="text-3xl sm:text-4xl font-extrabold text-rose-700 tracking-tight">
                {stats.fulfilledRequests.toLocaleString()}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-700 mt-1">Fulfilled Transfusions</div>
              <div className="text-[11px] text-emerald-600 font-bold mt-0.5">
                {stats.fulfillmentRatePercentage}% Fulfillment Rate
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Urgent Requests Live Board */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 rounded bg-red-100 text-red-600 text-xs font-bold uppercase animate-pulse">
                🚨 Live Emergency Requests
              </span>
              <span className="text-xs text-slate-400 font-medium">Auto-sorted by medical urgency</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mt-1">Urgent Hospital Needs</h2>
          </div>
          <button
            onClick={() => setActivePage('request-blood')}
            className="text-xs font-bold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-3.5 py-2 rounded-lg transition"
          >
            + Create New Blood Request
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {emergencyRequests.slice(0, 3).map((req) => (
            <div 
              key={req.id} 
              className={`bg-white rounded-2xl border p-5 shadow-sm transition hover:shadow-md relative overflow-hidden ${
                req.urgency === 'EMERGENCY' ? 'border-red-300 ring-1 ring-red-200' : 'border-slate-200'
              }`}
            >
              {req.urgency === 'EMERGENCY' && (
                <div className="absolute top-0 right-0 bg-red-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-bl-lg tracking-wider">
                  Critical ICU
                </div>
              )}

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 text-white font-extrabold text-lg flex items-center justify-center shadow-xs">
                    {req.requiredBloodGroup}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{req.patientName}</h4>
                    <span className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-rose-500" /> {req.hospitalLocation}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600 mb-4 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="flex justify-between">
                  <span className="text-slate-400">Hospital:</span>
                  <span className="font-semibold text-slate-800 truncate max-w-[170px]">{req.hospitalName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Units Needed:</span>
                  <span className="font-bold text-rose-700">{req.numberOfUnits} Unit(s)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Contact:</span>
                  <span className="font-mono font-medium">{req.contactNumber}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    if (onSelectRequestForResponse) onSelectRequestForResponse(req);
                    setActivePage('donor-profile');
                  }}
                  className="flex-1 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-2 rounded-lg transition text-center"
                >
                  Respond as Donor
                </button>
                <a
                  href={`tel:${req.contactNumber}`}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
                  title="Direct Call"
                >
                  📞
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-extrabold uppercase tracking-widest text-rose-600">Simple Process</span>
          <h2 className="text-3xl font-extrabold text-slate-900 mt-1">How BloodConnect Operates</h2>
          <p className="text-sm text-slate-600 mt-2">
            A reliable 3-step pipeline designed to minimize emergency response latency when every second matters.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center relative">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 text-rose-700 font-extrabold text-xl flex items-center justify-center mb-4">
              1
            </div>
            <h3 className="font-bold text-slate-900 text-lg mb-2">Search or Request</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Family members or hospital coordinators specify blood type, location, and units required. Alternatively, search voluntary donors directly by city.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center relative">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 text-rose-700 font-extrabold text-xl flex items-center justify-center mb-4">
              2
            </div>
            <h3 className="font-bold text-slate-900 text-lg mb-2">Biological Matching</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Our relational database engine queries verified, available voluntary donors matching biological antigen compatibility rules and alerts nearby volunteers.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center relative">
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 text-rose-700 font-extrabold text-xl flex items-center justify-center mb-4">
              3
            </div>
            <h3 className="font-bold text-slate-900 text-lg mb-2">Life Saved</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Donors confirm arrival at the medical center. Transfusion is securely completed, and ticket status updates to fulfilled in real-time.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
