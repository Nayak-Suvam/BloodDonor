import React, { useState } from 'react';
import { User, Donor, BloodRequest } from '../types/bloodconnect';
import { 
  ShieldCheck, 
  MapPin, 
  Phone, 
  Award, 
  Calendar, 
  Clock, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  Heart,
  Droplet
} from 'lucide-react';

interface DonorProfileViewProps {
  currentUser: User | null;
  donors: Donor[];
  emergencyRequests: BloodRequest[];
  onUpdateAvailability: (donorId: number, status: 'AVAILABLE' | 'UNAVAILABLE') => void;
  onRequestAccepted: (requestId: number) => void;
  setActivePage: (page: string) => void;
}

export const DonorProfileView: React.FC<DonorProfileViewProps> = ({
  currentUser,
  donors,
  emergencyRequests,
  onUpdateAvailability,
  onRequestAccepted,
  setActivePage
}) => {
  // Find current donor profile or default to demo donor Aarav
  const currentDonor = donors.find((d) => d.email === currentUser?.email) || donors[0];

  const [availability, setAvailability] = useState<'AVAILABLE' | 'UNAVAILABLE'>(
    currentDonor?.availabilityStatus === 'AVAILABLE' ? 'AVAILABLE' : 'UNAVAILABLE'
  );
  const [successToast, setSuccessToast] = useState<string>('');

  const handleToggle = () => {
    const nextStatus = availability === 'AVAILABLE' ? 'UNAVAILABLE' : 'AVAILABLE';
    setAvailability(nextStatus);
    if (currentDonor) {
      onUpdateAvailability(currentDonor.id, nextStatus);
    }
    setSuccessToast(`Availability status updated to ${nextStatus} in MySQL database.`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  const handleAccept = (req: BloodRequest) => {
    onRequestAccepted(req.id);
    setSuccessToast(`Thank you! Hospital coordinator at ${req.hospitalName} has been notified that you are en route for ${req.patientName}.`);
    setTimeout(() => setSuccessToast(''), 5000);
  };

  // Badge tier calculation
  const getBadgeTier = (count: number) => {
    if (count >= 8) return { label: 'Gold Life Saver', color: 'bg-amber-100 text-amber-800 border-amber-300' };
    if (count >= 4) return { label: 'Silver Life Saver', color: 'bg-slate-200 text-slate-800 border-slate-300' };
    return { label: 'Bronze Life Saver', color: 'bg-orange-100 text-orange-800 border-orange-200' };
  };

  const badge = getBadgeTier(currentDonor?.totalDonations || 5);

  // Matching emergency requests (same blood group or universal compatibility)
  const matchedRequests = emergencyRequests.filter(
    (req) => req.requiredBloodGroup === currentDonor?.bloodGroup || currentDonor?.bloodGroup === 'O-'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Toast Notification */}
      {successToast && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Profile Overview Card */}
      <div className="bg-gradient-to-r from-white via-rose-50/50 to-white rounded-3xl border border-rose-100 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-rose-500 to-rose-700 text-white font-black text-3xl flex items-center justify-center shadow-lg shadow-rose-500/25">
              {currentDonor?.bloodGroup || 'O+'}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  {currentDonor?.fullName || currentUser?.fullName || 'Aarav Sharma'}
                </h1>
                <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                  availability === 'AVAILABLE' 
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300' 
                    : 'bg-amber-100 text-amber-800 border-amber-300'
                }`}>
                  ● {availability === 'AVAILABLE' ? 'Available to Donate' : 'Busy / In Cooldown'}
                </span>
              </div>
              
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1.5">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" /> {currentDonor?.city || 'Mumbai'}, Maharashtra
                </span>
                <span>• Age: {currentDonor?.age || 28}</span>
                <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified Voluntary Donor
                </span>
              </div>
            </div>
          </div>

          {/* Availability Toggle Box */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs text-center w-full md:w-auto">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Donation Readiness Switch
            </div>
            <button
              onClick={handleToggle}
              className={`w-full md:w-auto px-5 py-2.5 rounded-xl font-bold text-xs transition shadow-xs ${
                availability === 'AVAILABLE'
                  ? 'bg-amber-500 hover:bg-amber-600 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              {availability === 'AVAILABLE' ? 'Set as Unavailable (Resting)' : 'Set as Available (Ready to Donate)'}
            </button>
          </div>

        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-center">
          <div className="text-3xl font-extrabold text-rose-600">
            {currentDonor?.totalDonations || 5}
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Transfusions Completed</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Lives directly impacted</div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-center">
          <div className="text-2xl font-extrabold text-slate-800">
            {badge.label}
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Life Saver Achievement</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-0.5">Recognized Contributor</div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-center">
          <div className="text-2xl font-extrabold text-emerald-600">
            Eligible
          </div>
          <div className="text-xs font-bold text-slate-700 mt-1">Medical Interval (&gt; 90 Days)</div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Last Donated: {currentDonor?.lastDonationDate || '2024-08-15'}
          </div>
        </div>
      </div>

      {/* Matching Emergency Requests Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span>Emergency Requests Matching Your Blood Group ({currentDonor?.bloodGroup || 'O+'})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Patients requiring immediate transfusion where your blood group is biologically compatible.
            </p>
          </div>
          <button
            onClick={() => setActivePage('request-blood')}
            className="text-xs font-bold text-rose-600 hover:underline"
          >
            View all requests board →
          </button>
        </div>

        {matchedRequests.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-xs text-slate-500">
            No active emergency requests currently pending for {currentDonor?.bloodGroup}.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {matchedRequests.map((req) => (
              <div 
                key={req.id} 
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition space-y-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 text-white font-extrabold text-base flex items-center justify-center">
                        {req.requiredBloodGroup}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{req.patientName}</h4>
                        <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-rose-500" />
                          <span>{req.hospitalLocation} • {req.numberOfUnits} unit(s)</span>
                        </div>
                      </div>
                    </div>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      req.urgency === 'EMERGENCY' 
                        ? 'bg-red-100 text-red-800 animate-pulse' 
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {req.urgency}
                    </span>
                  </div>

                  <div className="mt-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs text-slate-600 space-y-1">
                    <div><strong>Hospital:</strong> {req.hospitalName}</div>
                    {req.additionalMessage && (
                      <div className="text-slate-500 italic">"{req.additionalMessage}"</div>
                    )}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex gap-2">
                  <button
                    onClick={() => handleAccept(req)}
                    className="flex-1 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-2 rounded-xl transition"
                  >
                    Accept & Coordinate Transfusion
                  </button>
                  <a
                    href={`tel:${req.contactNumber}`}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
                    title="Call Hospital Line"
                  >
                    📞
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Donation History Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
        <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider">
          Personal Donation History Record (MySQL <code>donor_request_connections</code>)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold">
                <th className="p-3">Donation Date</th>
                <th className="p-3">Hospital Center</th>
                <th className="p-3">Blood Component</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              <tr>
                <td className="p-3 font-semibold">2024-08-15</td>
                <td className="p-3">Lilavati Hospital, Mumbai</td>
                <td className="p-3">Whole Blood (1 Unit)</td>
                <td className="p-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">Completed</span></td>
              </tr>
              <tr>
                <td className="p-3 font-semibold">2024-04-10</td>
                <td className="p-3">Hinduja National Hospital, Mumbai</td>
                <td className="p-3">Platelet Apheresis</td>
                <td className="p-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">Completed</span></td>
              </tr>
              <tr>
                <td className="p-3 font-semibold">2023-11-20</td>
                <td className="p-3">Kokilaben Dhirubhai Ambani Hospital</td>
                <td className="p-3">Whole Blood (1 Unit)</td>
                <td className="p-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">Completed</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
