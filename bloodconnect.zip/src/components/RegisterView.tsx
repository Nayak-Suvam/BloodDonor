import React, { useState } from 'react';
import { BloodGroupType, Donor } from '../types/bloodconnect';
import { ShieldCheck, Heart, UserPlus, CheckCircle2, Lock, AlertCircle } from 'lucide-react';

interface RegisterViewProps {
  onRegisterSuccess: (donor: Donor) => void;
  setActivePage: (page: string) => void;
}

export const RegisterView: React.FC<RegisterViewProps> = ({
  onRegisterSuccess,
  setActivePage
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState<number>(25);
  const [bloodGroup, setBloodGroup] = useState<BloodGroupType>('O+');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [lastDonationDate, setLastDonationDate] = useState('');
  
  // Eligibility check state
  const [weightOk, setWeightOk] = useState(true);
  const [healthOk, setHealthOk] = useState(true);
  const [cooldownOk, setCooldownOk] = useState(true);
  const [ethicsOk, setEthicsOk] = useState(true);

  const bloodGroups: BloodGroupType[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !email.trim() || !password.trim() || !phoneNumber.trim() || !city.trim() || !address.trim()) {
      alert('Please fill out all mandatory fields.');
      return;
    }

    if (age < 18 || age > 65) {
      alert('Voluntary donors must be between 18 and 65 years of age.');
      return;
    }

    if (!weightOk || !healthOk || !cooldownOk || !ethicsOk) {
      alert('You must confirm all medical eligibility criteria before registering.');
      return;
    }

    const newDonor: Donor = {
      id: Date.now(),
      userId: Date.now() + 1,
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      age,
      bloodGroup,
      phoneNumber: phoneNumber.trim(),
      city: city.trim(),
      address: address.trim(),
      availabilityStatus: 'AVAILABLE',
      lastDonationDate: lastDonationDate || null,
      totalDonations: 0,
      createdAt: new Date().toISOString()
    };

    onRegisterSuccess(newDonor);
    setActivePage('donor-profile');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800">
          <span>❤️ Voluntary Life Saver Onboarding</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Register as a Blood Donor
        </h1>
        <p className="text-sm text-slate-600">
          Your voluntary donation is an invaluable gift to humanity. Fill in your details below to join our verified donor network.
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-sm space-y-8">
        
        {/* Donor Privacy Assurance Banner */}
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-800">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block font-bold">Privacy & Address Security Guaranteed</strong>
            <p className="text-emerald-700 leading-relaxed">
              Your exact street address is never exposed on public search results. It is stored securely in MySQL <code>donors.address</code> and only referenced for localized radius calculation and verified hospital dispatch.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Section 1: Account Access */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-700 text-xs flex items-center justify-center font-extrabold">1</span>
              <span>Account Credentials</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Aarav Sharma"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="aarav@example.com"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Password * (Minimum 6 characters)
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Section 2: Biological & Contact */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-700 text-xs flex items-center justify-center font-extrabold">2</span>
              <span>Medical & Contact Details</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Blood Group *
                </label>
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value as BloodGroupType)}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500 bg-white"
                >
                  {bloodGroups.map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Age (18 - 65) *
                </label>
                <input
                  type="number"
                  min="18"
                  max="65"
                  required
                  value={age}
                  onChange={(e) => setAge(parseInt(e.target.value, 10))}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Mobile Phone *
                </label>
                <input
                  type="tel"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  City / District *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Mumbai"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Residential Address *</span>
                  <span className="text-[10px] text-emerald-600 font-bold">🔒 Protected</span>
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street / locality / postal code"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Last Blood Donation Date (Leave blank if first-time donor)
              </label>
              <input
                type="date"
                value={lastDonationDate}
                onChange={(e) => setLastDonationDate(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Section 3: Medical Eligibility Checklist */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Medical Eligibility Declaration
            </h4>
            
            <div className="space-y-2 text-xs text-slate-700">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={weightOk}
                  onChange={(e) => setWeightOk(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded"
                />
                <span>I weigh at least 50 kg (110 lbs) and my hemoglobin levels are normal.</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={healthOk}
                  onChange={(e) => setHealthOk(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded"
                />
                <span>I do not have chronic cardiovascular issues, active infections, or communicable bloodborne diseases.</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={cooldownOk}
                  onChange={(e) => setCooldownOk(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded"
                />
                <span>It has been at least 90 days since my last whole blood donation (cooldown period).</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={ethicsOk}
                  onChange={(e) => setEthicsOk(e.target.checked)}
                  className="w-4 h-4 text-rose-600 rounded"
                />
                <span>I agree to be a voluntary unpaid donor in accordance with national healthcare guidelines.</span>
              </label>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-xl font-bold text-white bg-gradient-to-r from-rose-600 via-rose-700 to-rose-800 hover:from-rose-700 hover:to-rose-900 shadow-lg shadow-rose-600/25 transition text-base flex items-center justify-center gap-2"
          >
            <UserPlus className="w-5 h-5" /> Complete Registration & Activate Profile
          </button>

          <p className="text-center text-xs text-slate-500">
            Already registered?{' '}
            <button
              type="button"
              onClick={() => setActivePage('login')}
              className="font-bold text-rose-600 hover:underline"
            >
              Sign In to Your Account
            </button>
          </p>

        </form>

      </div>

    </div>
  );
};
