import React from 'react';
import { User } from '../types/bloodconnect';
import { Droplet, Heart, Server, LogIn, UserPlus, LogOut, Search, PlusCircle, Info, Home } from 'lucide-react';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenExplorer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  currentUser,
  onLogout,
  onOpenExplorer
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-rose-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo */}
          <div 
            onClick={() => setActivePage('index')}
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 flex items-center justify-center text-white shadow-md shadow-rose-500/25 group-hover:scale-105 transition-transform">
              <span className="text-xl animate-heartbeat">🩸</span>
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-rose-700 to-rose-900 bg-clip-text text-transparent">
                BloodConnect
              </span>
              <span className="block text-[10px] font-bold text-rose-500 tracking-wider uppercase -mt-1">
                Life Saver Network
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1">
            <button
              onClick={() => setActivePage('index')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition ${
                activePage === 'index'
                  ? 'bg-rose-50 text-rose-700 font-bold'
                  : 'text-slate-600 hover:text-rose-600 hover:bg-slate-50'
              }`}
            >
              <Home className="w-4 h-4" /> Home
            </button>
            <button
              onClick={() => setActivePage('find-donor')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition ${
                activePage === 'find-donor'
                  ? 'bg-rose-50 text-rose-700 font-bold'
                  : 'text-slate-600 hover:text-rose-600 hover:bg-slate-50'
              }`}
            >
              <Search className="w-4 h-4" /> Find Donors
            </button>
            <button
              onClick={() => setActivePage('request-blood')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition ${
                activePage === 'request-blood'
                  ? 'bg-rose-50 text-rose-700 font-bold'
                  : 'text-slate-600 hover:text-rose-600 hover:bg-slate-50'
              }`}
            >
              <PlusCircle className="w-4 h-4" /> Request Blood
            </button>
            <button
              onClick={() => setActivePage('about')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition ${
                activePage === 'about'
                  ? 'bg-rose-50 text-rose-700 font-bold'
                  : 'text-slate-600 hover:text-rose-600 hover:bg-slate-50'
              }`}
            >
              <Info className="w-4 h-4" /> About
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2.5">
            {/* Spring Boot & MySQL Explorer trigger */}
            <button
              onClick={onOpenExplorer}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold bg-slate-900 text-slate-100 hover:bg-slate-800 px-3 py-2 rounded-lg border border-slate-700 shadow-sm transition"
              title="Inspect Java Spring Boot 3 & MySQL Architecture"
            >
              <Server className="w-3.5 h-3.5 text-rose-400" />
              <span>Spring Boot & MySQL Hub</span>
            </button>

            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActivePage('donor-profile')}
                  className={`text-xs font-bold px-3 py-1.5 rounded-lg border transition ${
                    activePage === 'donor-profile'
                      ? 'bg-rose-600 text-white border-rose-600'
                      : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                  }`}
                >
                  👤 {currentUser.fullName.split(' ')[0]}'s Profile
                </button>
                <button
                  onClick={onLogout}
                  className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActivePage('login')}
                  className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-slate-700 hover:text-rose-600 px-3 py-2 rounded-lg hover:bg-slate-50 transition"
                >
                  <LogIn className="w-3.5 h-3.5" /> Log In
                </button>
                <button
                  onClick={() => setActivePage('register')}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white px-3.5 py-2 rounded-lg shadow-sm shadow-rose-600/30 transition transform hover:-translate-y-0.5"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Become a Donor
                </button>
              </div>
            )}
          </div>

        </div>
      </div>
      
      {/* Mobile Nav strip */}
      <div className="md:hidden border-t border-slate-100 bg-slate-50/80 px-4 py-2 flex justify-around text-xs font-bold">
        <button 
          onClick={() => setActivePage('index')} 
          className={`py-1 ${activePage === 'index' ? 'text-rose-600 border-b-2 border-rose-600' : 'text-slate-600'}`}
        >
          Home
        </button>
        <button 
          onClick={() => setActivePage('find-donor')} 
          className={`py-1 ${activePage === 'find-donor' ? 'text-rose-600 border-b-2 border-rose-600' : 'text-slate-600'}`}
        >
          Find Donor
        </button>
        <button 
          onClick={() => setActivePage('request-blood')} 
          className={`py-1 ${activePage === 'request-blood' ? 'text-rose-600 border-b-2 border-rose-600' : 'text-slate-600'}`}
        >
          Request
        </button>
        <button 
          onClick={() => setActivePage('about')} 
          className={`py-1 ${activePage === 'about' ? 'text-rose-600 border-b-2 border-rose-600' : 'text-slate-600'}`}
        >
          About
        </button>
        <button 
          onClick={onOpenExplorer} 
          className="py-1 text-rose-700 font-extrabold flex items-center gap-1"
        >
          <Server className="w-3 h-3" /> Java Hub
        </button>
      </div>
    </header>
  );
};
