import React, { useState, useMemo } from 'react';
import { Donor, BloodGroupType } from '../types/bloodconnect';
import { BLOOD_COMPATIBILITY_MAP } from '../data/mockData';
import { Search, MapPin, Phone, CheckCircle, Shield, Filter, Calendar, Award } from 'lucide-react';

interface FindDonorViewProps {
  donors: Donor[];
  onDonorContact?: (donor: Donor) => void;
}

export const FindDonorView: React.FC<FindDonorViewProps> = ({ donors }) => {
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<string>('');
  const [searchCity, setSearchCity] = useState<string>('');
  const [availabilityFilter, setAvailabilityFilter] = useState<string>('AVAILABLE');
  const [includeCompatible, setIncludeCompatible] = useState<boolean>(false);
  const [contactedDonor, setContactedDonor] = useState<Donor | null>(null);

  const bloodGroups: BloodGroupType[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const popularCities = ['Mumbai', 'Delhi', 'Bangalore', 'Kolkata', 'Hyderabad', 'Chennai', 'Pune'];

  // Filter logic
  const filteredDonors = useMemo(() => {
    return donors.filter((donor) => {
      // Blood Group filtering
      if (selectedBloodGroup) {
        if (includeCompatible) {
          const compatibleTypes = BLOOD_COMPATIBILITY_MAP[selectedBloodGroup as BloodGroupType] || [];
          if (!compatibleTypes.includes(donor.bloodGroup)) {
            return false;
          }
        } else {
          if (donor.bloodGroup !== selectedBloodGroup) {
            return false;
          }
        }
      }

      // City filtering
      if (searchCity.trim()) {
        if (!donor.city.toLowerCase().includes(searchCity.trim().toLowerCase())) {
          return false;
        }
      }

      // Availability filtering
      if (availabilityFilter && donor.availabilityStatus !== availabilityFilter) {
        return false;
      }

      return true;
    });
  }, [donors, selectedBloodGroup, searchCity, availabilityFilter, includeCompatible]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800">
          <span>🔍 Voluntary Donor Directory</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Find Blood Donors in Your Area
        </h1>
        <p className="text-sm text-slate-600">
          Filter through our database of registered voluntary donors. Protected contact info ensures donors are safeguarded while enabling emergency coordination.
        </p>
      </div>

      {/* Filter Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
        
        {/* Blood Group Selector Chips */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Select Patient's Required Blood Group
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedBloodGroup('')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition ${
                selectedBloodGroup === ''
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Types
            </button>
            {bloodGroups.map((bg) => (
              <button
                key={bg}
                onClick={() => setSelectedBloodGroup(bg)}
                className={`px-4 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1 ${
                  selectedBloodGroup === bg
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 ring-2 ring-rose-600/20'
                    : 'bg-rose-50 text-rose-700 border border-rose-100 hover:bg-rose-100'
                }`}
              >
                <span>🩸</span>
                <span>{bg}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Search City & Availability */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          <div className="md:col-span-6 relative">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              City or District
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchCity}
                onChange={(e) => setSearchCity(e.target.value)}
                placeholder="Search city e.g. Mumbai, Delhi, Bangalore..."
                className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
              />
            </div>
            {/* Quick city suggestions */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              <span className="text-[11px] text-slate-400 font-medium">Popular:</span>
              {popularCities.slice(0, 5).map((city) => (
                <button
                  key={city}
                  onClick={() => setSearchCity(city)}
                  className="text-[11px] text-rose-700 bg-rose-50 hover:bg-rose-100 px-2 py-0.5 rounded-md font-medium"
                >
                  {city}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Availability
            </label>
            <select
              value={availabilityFilter}
              onChange={(e) => setAvailabilityFilter(e.target.value)}
              className="w-full py-2 px-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-rose-500"
            >
              <option value="">Any Status</option>
              <option value="AVAILABLE">Available Right Now</option>
              <option value="UNAVAILABLE">Busy / In Cooldown</option>
            </select>
          </div>

          <div className="md:col-span-3 flex flex-col justify-end pt-5">
            <label className="flex items-center gap-2 cursor-pointer bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition">
              <input
                type="checkbox"
                checked={includeCompatible}
                onChange={(e) => setIncludeCompatible(e.target.checked)}
                className="w-4 h-4 text-rose-600 rounded focus:ring-rose-500"
              />
              <span>Include Compatible Donors</span>
            </label>
          </div>

        </div>

      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
        <div>
          Showing <span className="font-bold text-slate-900">{filteredDonors.length}</span> verified donors
          {selectedBloodGroup && (
            <span> for <strong className="text-rose-600">{selectedBloodGroup}</strong> {includeCompatible ? '(compatible included)' : ''}</span>
          )}
          {searchCity && <span> in <strong className="text-slate-900">{searchCity}</strong></span>}
        </div>
        <div className="text-[11px] text-slate-400">
          Source: MySQL 8 <code>donors</code> table
        </div>
      </div>

      {/* Donors Cards Grid */}
      {filteredDonors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto text-2xl">
            🩸
          </div>
          <h3 className="text-lg font-bold text-slate-800">No matching donors located</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Try clearing the city filter, checking "Include Compatible Donors", or post an urgent blood request to alert unregistered volunteers nearby.
          </p>
          <button
            onClick={() => {
              setSelectedBloodGroup('');
              setSearchCity('');
              setAvailabilityFilter('');
            }}
            className="text-xs font-bold text-rose-600 hover:underline pt-2"
          >
            Reset all search filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDonors.map((donor) => (
            <div
              key={donor.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition space-y-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 text-white font-extrabold text-lg flex items-center justify-center shadow-xs">
                      {donor.bloodGroup}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{donor.fullName}</h3>
                      <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                        <MapPin className="w-3 h-3 text-rose-500" />
                        <span>{donor.city} • Age: {donor.age}</span>
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                      donor.availabilityStatus === 'AVAILABLE'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    ● {donor.availabilityStatus}
                  </span>
                </div>

                {/* Donor stats pills */}
                <div className="grid grid-cols-2 gap-2 mt-4 text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total Donations:</span>
                    <span className="font-bold text-slate-800">{donor.totalDonations} times</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Last Donated:</span>
                    <span className="font-semibold text-slate-800">
                      {donor.lastDonationDate || 'First-time donor'}
                    </span>
                  </div>
                </div>

                {/* Protected address notice */}
                <div className="mt-2 text-[10px] text-slate-400 flex items-center gap-1">
                  <Shield className="w-3 h-3 text-emerald-600" />
                  <span>Exact residential street protected</span>
                </div>
              </div>

              {/* Action */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => setContactedDonor(donor)}
                  className="w-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5" /> Contact Voluntary Donor
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Contact Donor Modal */}
      {contactedDonor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-600 text-white font-extrabold flex items-center justify-center text-xs">
                  {contactedDonor.bloodGroup}
                </div>
                <h3 className="font-bold text-slate-900">Direct Contact with Donor</h3>
              </div>
              <button
                onClick={() => setContactedDonor(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 leading-relaxed">
                You are connecting with voluntary donor <strong>{contactedDonor.fullName}</strong> for patient emergency assistance.
              </p>

              <div className="bg-rose-50 p-3 rounded-xl border border-rose-100 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Phone Number:</span>
                  <span className="font-mono font-bold text-slate-900">{contactedDonor.phoneNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Location:</span>
                  <span className="font-semibold text-slate-800">{contactedDonor.city}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Eligibility Status:</span>
                  <span className="text-emerald-700 font-bold">Eligible & Ready</span>
                </div>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-[11px] text-slate-500">
                🔒 <em>Ethical Protocol:</em> Commercial blood sales are illegal. BloodConnect is strictly a voluntary altruistic network.
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <a
                href={`tel:${contactedDonor.phoneNumber}`}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 rounded-xl text-center transition flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5" /> Call {contactedDonor.phoneNumber}
              </a>
              <button
                onClick={() => {
                  alert(`Emergency SMS request dispatch simulated to ${contactedDonor.fullName}!`);
                  setContactedDonor(null);
                }}
                className="flex-1 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-2.5 rounded-xl text-center transition"
              >
                Send Request Alert
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
