import React from 'react';
import { PhoneCall, ShieldCheck, Heart, Server } from 'lucide-react';

interface FooterProps {
  setActivePage: (page: string) => void;
  onOpenExplorer: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setActivePage, onOpenExplorer }) => {
  return (
    <footer className="mt-auto bg-slate-950 text-slate-400 border-t border-slate-900 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-2xl animate-heartbeat">🩸</span>
              <span className="text-xl font-extrabold text-white tracking-tight">BloodConnect</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Full-Stack Blood Donor Discovery & Emergency Management Platform. Serving voluntary donors, patients in need, and medical centers across cities.
            </p>
            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-950/60 text-rose-300 border border-rose-900/40">
                <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
                Protected Donor Address Vault
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Platform Pages</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setActivePage('index')} className="hover:text-rose-400 transition">
                  Home (index.html)
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('find-donor')} className="hover:text-rose-400 transition">
                  Find Blood Donors (find-donor.html)
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('request-blood')} className="hover:text-rose-400 transition">
                  Request Blood (request-blood.html)
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('register')} className="hover:text-rose-400 transition">
                  Donor Registration (register.html)
                </button>
              </li>
            </ul>
          </div>

          {/* College Project Architecture */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Architecture & Tech</h4>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-1.5">
                <span className="text-rose-400 font-bold">Backend:</span> Java 21 & Spring Boot 3.2
              </li>
              <li className="flex items-center gap-1.5">
                <span className="text-rose-400 font-bold">Database:</span> MySQL 8.0 (InnoDB)
              </li>
              <li className="flex items-center gap-1.5">
                <span className="text-rose-400 font-bold">Security:</span> Stateless JWT & BCrypt
              </li>
              <li className="pt-2">
                <button 
                  onClick={onOpenExplorer}
                  className="inline-flex items-center gap-1.5 text-xs text-rose-400 font-bold hover:underline"
                >
                  <Server className="w-3.5 h-3.5" /> View Spring Boot Source Code
                </button>
              </li>
            </ul>
          </div>

          {/* Emergency & Support */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Emergency Lifeline</h4>
            <div className="bg-rose-950/40 border border-rose-900/60 rounded-xl p-3 mb-3">
              <div className="flex items-center gap-2 text-rose-400 text-xs font-bold mb-1">
                <PhoneCall className="w-4 h-4" /> National Blood Helpline
              </div>
              <div className="text-lg font-extrabold text-white">1910 / 108</div>
              <p className="text-[11px] text-slate-400 mt-1">24/7 Centralized emergency medical support</p>
            </div>
            <p className="text-[11px] text-slate-500">
              Demonstration records are clearly indicated for academic evaluation.
            </p>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div>
            &copy; 2026 BloodConnect Project. Designed & Built for Academic Presentation & Practical Deployment.
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setActivePage('about')} className="hover:text-slate-300 transition">About</button>
            <button onClick={() => setActivePage('login')} className="hover:text-slate-300 transition">Sign In</button>
            <button onClick={onOpenExplorer} className="text-rose-400 hover:text-rose-300 font-semibold transition">
              Spring Boot & MySQL Code
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
