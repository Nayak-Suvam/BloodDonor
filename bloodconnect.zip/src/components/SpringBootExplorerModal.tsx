import React, { useState } from 'react';
import { 
  FolderTree, 
  Database, 
  Terminal, 
  BookOpen, 
  FileCode, 
  Copy, 
  Check, 
  X, 
  Server, 
  ExternalLink,
  ShieldCheck,
  Cpu
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const SpringBootExplorerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'files' | 'schema' | 'api' | 'viva'>('files');
  const [selectedFile, setSelectedFile] = useState<string>('BloodConnect/pom.xml');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const filesMap: Record<string, { label: string; lang: string; content: string }> = {
    'BloodConnect/pom.xml': {
      label: 'pom.xml (Maven Dependencies)',
      lang: 'xml',
      content: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.5</version>
    </parent>
    <groupId>com.bloodconnect</groupId>
    <artifactId>bloodconnect</artifactId>
    <version>1.0.0</version>
    <name>BloodConnect</name>
    <description>Blood Donation Discovery and Emergency Request Management Platform</description>

    <properties>
        <java.version>21</java.version>
        <jjwt.version>0.12.5</jjwt.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>\${jjwt.version}</version>
        </dependency>
    </dependencies>
</project>`
    },
    'BloodConnect/database/schema.sql': {
      label: 'schema.sql (MySQL 8 DDL)',
      lang: 'sql',
      content: `-- ====================================================================
-- BloodConnect MySQL 8 Relational Schema
-- ====================================================================
CREATE DATABASE IF NOT EXISTS bloodconnect_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bloodconnect_db;

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL DEFAULT 'ROLE_DONOR',
    account_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

CREATE TABLE donors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNIQUE,
    age INT NOT NULL CHECK (age >= 18 AND age <= 65),
    blood_group VARCHAR(6) NOT NULL,
    phone_number VARCHAR(25) NOT NULL,
    city VARCHAR(80) NOT NULL,
    address VARCHAR(255) NOT NULL COMMENT 'Protected from public view',
    availability_status VARCHAR(32) NOT NULL DEFAULT 'AVAILABLE',
    last_donation_date DATE NULL,
    total_donations INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_donor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_donors_search (blood_group, city, availability_status)
) ENGINE=InnoDB;

CREATE TABLE blood_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(120) NOT NULL,
    required_blood_group VARCHAR(6) NOT NULL,
    number_of_units INT NOT NULL DEFAULT 1,
    contact_number VARCHAR(25) NOT NULL,
    hospital_name VARCHAR(150) NOT NULL,
    hospital_location VARCHAR(120) NOT NULL,
    urgency VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
    request_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    requester_id BIGINT NULL,
    CONSTRAINT fk_request_user FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_requests_urgency_status (urgency, request_status)
) ENGINE=InnoDB;`
    },
    'BloodConnect/src/main/java/com/bloodconnect/BloodConnectApplication.java': {
      label: 'BloodConnectApplication.java',
      lang: 'java',
      content: `package com.bloodconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(BloodConnectApplication.class, args);
        System.out.println("🩸 BloodConnect Platform Running at http://localhost:8080");
    }
}`
    },
    'BloodConnect/src/main/java/com/bloodconnect/config/SecurityConfig.java': {
      label: 'SecurityConfig.java (Spring Security 6)',
      lang: 'java',
      content: `package com.bloodconnect.config;

import com.bloodconnect.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public static PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/*.html", "/css/**", "/js/**", "/images/**").permitAll()
                .requestMatchers("/api/auth/**", "/api/stats/**", "/api/donors/search", "/api/requests").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            );

        http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}`
    },
    'BloodConnect/src/main/java/com/bloodconnect/controller/DonorController.java': {
      label: 'DonorController.java (REST Endpoints)',
      lang: 'java',
      content: `package com.bloodconnect.controller;

import com.bloodconnect.dto.*;
import com.bloodconnect.entity.Donor;
import com.bloodconnect.service.DonorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/donors")
@RequiredArgsConstructor
public class DonorController {

    private final DonorService donorService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registerDonor(@Valid @RequestBody RegisterDonorRequest request) {
        return new ResponseEntity<>(donorService.registerDonor(request), HttpStatus.CREATED);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Donor>> searchDonors(
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String availability,
            @RequestParam(required = false, defaultValue = "false") Boolean includeCompatible
    ) {
        DonorSearchCriteria criteria = DonorSearchCriteria.builder()
                .bloodGroup(bloodGroup)
                .city(city)
                .availability(availability)
                .includeCompatible(includeCompatible)
                .build();
        return ResponseEntity.ok(donorService.searchDonors(criteria));
    }
}`
    },
    'BloodConnect/src/main/resources/application.properties': {
      label: 'application.properties',
      lang: 'properties',
      content: `spring.application.name=BloodConnect
server.port=8080

# MySQL 8 Connection
spring.datasource.url=jdbc:mysql://localhost:3306/bloodconnect_db?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=root123
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA / Hibernate
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# Static Frontend Resources (Served without CORS)
spring.web.resources.static-locations=classpath:/static/
spring.mvc.static-path-pattern=/**

# JWT Secret
bloodconnect.jwt.secret=404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970`
    }
  };

  const handleCopy = () => {
    const text = filesMap[selectedFile]?.content || '';
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in duration-200">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 to-rose-950 px-6 py-4 flex items-center justify-between text-white border-b border-rose-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600/30 border border-rose-500/50 flex items-center justify-center text-rose-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-white">Java Spring Boot 3 & MySQL Architecture</h3>
                <span className="text-xs bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded-full font-semibold">
                  College Project Deliverable
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Complete backend source code, relational schema, REST API documentation & viva defense notes.
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-2">
          <button 
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition ${
              activeTab === 'files' 
                ? 'border-rose-600 text-rose-600 bg-white rounded-t-lg' 
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCode className="w-4 h-4" /> Source Code Files ({Object.keys(filesMap).length})
          </button>
          <button 
            onClick={() => setActiveTab('schema')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition ${
              activeTab === 'schema' 
                ? 'border-rose-600 text-rose-600 bg-white rounded-t-lg' 
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" /> MySQL ER Schema
          </button>
          <button 
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition ${
              activeTab === 'api' 
                ? 'border-rose-600 text-rose-600 bg-white rounded-t-lg' 
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Terminal className="w-4 h-4" /> REST API Endpoints
          </button>
          <button 
            onClick={() => setActiveTab('viva')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition ${
              activeTab === 'viva' 
                ? 'border-rose-600 text-rose-600 bg-white rounded-t-lg' 
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" /> Viva Q&A Guide
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-100">
          
          {/* TAB 1: FILE BROWSER */}
          {activeTab === 'files' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
              {/* File List */}
              <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-sm">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-2 py-1 mb-2">
                  Project Files Tree
                </div>
                <div className="space-y-1">
                  {Object.entries(filesMap).map(([path, file]) => (
                    <button
                      key={path}
                      onClick={() => setSelectedFile(path)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition flex items-center gap-2 ${
                        selectedFile === path 
                          ? 'bg-rose-50 text-rose-700 font-bold border border-rose-200' 
                          : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <FileCode className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{file.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Code Viewer */}
              <div className="md:col-span-2 bg-slate-950 text-slate-100 rounded-xl p-4 font-mono text-xs overflow-auto shadow-inner flex flex-col max-h-[520px]">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                  <span className="text-rose-400 font-semibold">{selectedFile}</span>
                  <button 
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded text-xs transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied!' : 'Copy Code'}
                  </button>
                </div>
                <pre className="overflow-x-auto leading-relaxed flex-1 text-slate-200">
                  {filesMap[selectedFile]?.content}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 2: SCHEMA */}
          {activeTab === 'schema' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-rose-600" /> Relational Architecture (MySQL 8)
                </h4>
                <p className="text-sm text-slate-600 mb-4">
                  The database models a strict 1-to-1 relationship between authenticated users and donor profiles, and 1-to-many relationships for hospital blood request tickets and responses.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
                    <div className="font-bold text-rose-700 text-sm mb-2 border-b border-slate-200 pb-1">
                      📋 users
                    </div>
                    <ul className="text-xs space-y-1 font-mono text-slate-600">
                      <li>• <strong>id</strong>: BIGINT (PK)</li>
                      <li>• <strong>full_name</strong>: VARCHAR(120)</li>
                      <li>• <strong>email</strong>: VARCHAR(160) (UNIQUE)</li>
                      <li>• <strong>password_hash</strong>: VARCHAR(255)</li>
                      <li>• <strong>role</strong>: VARCHAR(32)</li>
                      <li>• <strong>account_status</strong>: VARCHAR(32)</li>
                    </ul>
                  </div>

                  <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
                    <div className="font-bold text-rose-700 text-sm mb-2 border-b border-slate-200 pb-1">
                      🩸 donors
                    </div>
                    <ul className="text-xs space-y-1 font-mono text-slate-600">
                      <li>• <strong>id</strong>: BIGINT (PK)</li>
                      <li>• <strong>user_id</strong>: BIGINT (FK users)</li>
                      <li>• <strong>blood_group</strong>: VARCHAR(6)</li>
                      <li>• <strong>age</strong>: INT (18-65)</li>
                      <li>• <strong>phone_number</strong>: VARCHAR(25)</li>
                      <li>• <strong>city</strong>: VARCHAR(80)</li>
                      <li>• <strong>address</strong>: VARCHAR(255) (PROTECTED)</li>
                      <li>• <strong>availability_status</strong>: VARCHAR(32)</li>
                    </ul>
                  </div>

                  <div className="border border-slate-200 rounded-lg p-3 bg-slate-50">
                    <div className="font-bold text-rose-700 text-sm mb-2 border-b border-slate-200 pb-1">
                      🚨 blood_requests
                    </div>
                    <ul className="text-xs space-y-1 font-mono text-slate-600">
                      <li>• <strong>id</strong>: BIGINT (PK)</li>
                      <li>• <strong>patient_name</strong>: VARCHAR(120)</li>
                      <li>• <strong>required_blood_group</strong>: VARCHAR(6)</li>
                      <li>• <strong>number_of_units</strong>: INT</li>
                      <li>• <strong>hospital_name</strong>: VARCHAR(150)</li>
                      <li>• <strong>hospital_location</strong>: VARCHAR(120)</li>
                      <li>• <strong>urgency</strong>: NORMAL|URGENT|EMERGENCY</li>
                      <li>• <strong>request_status</strong>: PENDING|ACCEPTED|FULFILLED</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: API ENDPOINTS */}
          {activeTab === 'api' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="font-bold text-slate-900 mb-3">RESTful API Contract</h4>
                <div className="space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 rounded-lg border border-emerald-200">
                    <span className="font-bold text-emerald-700">POST /api/auth/login</span>
                    <span className="text-slate-500 font-sans text-xs">Public • Authenticates user and returns JWT Bearer token</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="font-bold text-blue-700">POST /api/donors/register</span>
                    <span className="text-slate-500 font-sans text-xs">Public • Registers voluntary donor with encrypted password</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-purple-50 rounded-lg border border-purple-200">
                    <span className="font-bold text-purple-700">GET /api/donors/search</span>
                    <span className="text-slate-500 font-sans text-xs">Public • Query params: ?bloodGroup=O+&city=Mumbai&availability=AVAILABLE</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-rose-50 rounded-lg border border-rose-200">
                    <span className="font-bold text-rose-700">POST /api/requests</span>
                    <span className="text-slate-500 font-sans text-xs">Public/Auth • Submits emergency blood request ticket</span>
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-amber-50 rounded-lg border border-amber-200">
                    <span className="font-bold text-amber-700">GET /api/stats</span>
                    <span className="text-slate-500 font-sans text-xs">Public • Real-time registered donors, active requests & fulfillment metrics</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: VIVA Q&A */}
          {activeTab === 'viva' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <div>
                  <h5 className="font-bold text-slate-900 text-sm mb-1 text-rose-700">
                    Q: Why use Spring Boot 3 & Java 21 for this project?
                  </h5>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Spring Boot provides enterprise-grade performance, out-of-the-box transaction management (ACID), automatic ORM mapping via Hibernate, and an embedded Tomcat server capable of serving both REST APIs and static frontend resources simultaneously from the same origin without CORS complications.
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-slate-900 text-sm mb-1 text-rose-700">
                    Q: How is donor address confidentiality enforced?
                  </h5>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    The <code>address</code> field in <code>Donor.java</code> is annotated with <code>@JsonIgnore</code>. It is stored securely in MySQL for hospital verification but is filtered out by Jackson serializer, preventing public scraper bots from harvesting donor locations.
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-slate-900 text-sm mb-1 text-rose-700">
                    Q: How does the biological blood compatibility engine work?
                  </h5>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    The <code>BloodGroup</code> enum implements <code>getCompatibleDonorGroups()</code>. For example, when an AB+ patient requires blood, the query expands to all groups (Universal Recipient). When an O- patient requests blood, it strictly matches only O- donors (Universal Red Cell Donor).
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-white px-6 py-3.5 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Ready for Maven compile: <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800">mvn spring-boot:run</code></span>
          </div>
          <button 
            onClick={onClose} 
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition"
          >
            Close Explorer
          </button>
        </div>

      </div>
    </div>
  );
};
