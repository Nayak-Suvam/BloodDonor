export type BloodGroupType = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export type UrgencyType = 'NORMAL' | 'URGENT' | 'EMERGENCY';

export type RequestStatusType = 'PENDING' | 'ACCEPTED' | 'FULFILLED' | 'CANCELLED';

export type AvailabilityType = 'AVAILABLE' | 'UNAVAILABLE' | 'ON_COOLDOWN';

export type UserRole = 'ROLE_DONOR' | 'ROLE_REQUESTER' | 'ROLE_ADMIN';

export interface User {
  id: number;
  fullName: string;
  email: string;
  role: UserRole;
  accountStatus: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
}

export interface Donor {
  id: number;
  userId: number;
  fullName: string;
  email: string;
  age: number;
  bloodGroup: BloodGroupType;
  phoneNumber: string;
  city: string;
  address: string; // Protected field
  availabilityStatus: AvailabilityType;
  lastDonationDate: string | null;
  totalDonations: number;
  createdAt: string;
}

export interface BloodRequest {
  id: number;
  patientName: string;
  requiredBloodGroup: BloodGroupType;
  numberOfUnits: number;
  contactNumber: string;
  hospitalName: string;
  hospitalLocation: string;
  urgency: UrgencyType;
  additionalMessage?: string;
  requestStatus: RequestStatusType;
  requesterId?: number;
  requesterName?: string;
  createdAt: string;
}

export interface PlatformStats {
  registeredDonors: number;
  availableDonors: number;
  totalBloodRequests: number;
  fulfilledRequests: number;
  fulfillmentRatePercentage: number;
}
