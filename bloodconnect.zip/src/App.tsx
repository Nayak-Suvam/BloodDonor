/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { User, Donor, BloodRequest, PlatformStats } from './types/bloodconnect';
import { INITIAL_DEMO_DONORS, INITIAL_DEMO_REQUESTS } from './data/mockData';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { FindDonorView } from './components/FindDonorView';
import { RequestBloodView } from './components/RequestBloodView';
import { RegisterView } from './components/RegisterView';
import { LoginView } from './components/LoginView';
import { AboutView } from './components/AboutView';
import { DonorProfileView } from './components/DonorProfileView';
import { SpringBootExplorerModal } from './components/SpringBootExplorerModal';

export default function App() {
  // Navigation: matches index.html, find-donor.html, request-blood.html, register.html, login.html, about.html, donor-profile.html
  const [activePage, setActivePage] = useState<string>('index');
  const [isExplorerOpen, setIsExplorerOpen] = useState<boolean>(false);

  // Donors State with localStorage persistence
  const [donors, setDonors] = useState<Donor[]>(() => {
    try {
      const saved = localStorage.getItem('bloodconnect_donors');
      return saved ? JSON.parse(saved) : INITIAL_DEMO_DONORS;
    } catch {
      return INITIAL_DEMO_DONORS;
    }
  });

  // Requests State with localStorage persistence
  const [bloodRequests, setBloodRequests] = useState<BloodRequest[]>(() => {
    try {
      const saved = localStorage.getItem('bloodconnect_requests');
      return saved ? JSON.parse(saved) : INITIAL_DEMO_REQUESTS;
    } catch {
      return INITIAL_DEMO_REQUESTS;
    }
  });

  // Authenticated User State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('bloodconnect_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Persist donors & requests
  useEffect(() => {
    localStorage.setItem('bloodconnect_donors', JSON.stringify(donors));
  }, [donors]);

  useEffect(() => {
    localStorage.setItem('bloodconnect_requests', JSON.stringify(bloodRequests));
  }, [bloodRequests]);

  // Dynamic Database Stats
  const stats: PlatformStats = useMemo(() => {
    const registered = donors.length;
    const available = donors.filter((d) => d.availabilityStatus === 'AVAILABLE').length;
    const totalRequests = bloodRequests.length;
    const fulfilled = bloodRequests.filter((r) => r.requestStatus === 'FULFILLED').length;
    const rate = totalRequests > 0 ? (fulfilled / totalRequests) * 100 : 95.0;

    return {
      registeredDonors: 1280 + registered,
      availableDonors: 430 + available,
      totalBloodRequests: 880 + totalRequests,
      fulfilledRequests: 840 + fulfilled,
      fulfillmentRatePercentage: Math.round(rate * 10) / 10,
    };
  }, [donors, bloodRequests]);

  // Top urgent emergency requests
  const emergencyRequests = useMemo(() => {
    return [...bloodRequests].sort((a, b) => {
      const priority = { EMERGENCY: 1, URGENT: 2, NORMAL: 3 };
      return priority[a.urgency] - priority[b.urgency];
    });
  }, [bloodRequests]);

  // Handlers
  const handleRequestSubmitted = (newReqData: Omit<BloodRequest, 'id' | 'createdAt' | 'requestStatus'>) => {
    const newRequest: BloodRequest = {
      ...newReqData,
      id: Date.now(),
      createdAt: new Date().toISOString(),
      requestStatus: 'PENDING',
      requesterName: currentUser?.fullName || 'Hospital Direct'
    };
    setBloodRequests((prev) => [newRequest, ...prev]);
  };

  const handleRegisterSuccess = (newDonor: Donor) => {
    setDonors((prev) => [newDonor, ...prev]);
    const user: User = {
      id: newDonor.userId,
      fullName: newDonor.fullName,
      email: newDonor.email,
      role: 'ROLE_DONOR',
      accountStatus: 'ACTIVE',
      createdAt: newDonor.createdAt
    };
    setCurrentUser(user);
    localStorage.setItem('bloodconnect_user', JSON.stringify(user));
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('bloodconnect_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('bloodconnect_user');
    localStorage.removeItem('bloodconnect_token');
    setActivePage('index');
  };

  const handleUpdateAvailability = (donorId: number, status: 'AVAILABLE' | 'UNAVAILABLE') => {
    setDonors((prev) =>
      prev.map((d) => (d.id === donorId ? { ...d, availabilityStatus: status } : d))
    );
  };

  const handleRequestAccepted = (requestId: number) => {
    setBloodRequests((prev) =>
      prev.map((r) => (r.id === requestId ? { ...r, requestStatus: 'ACCEPTED' } : r))
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans selection:bg-rose-500 selection:text-white">
      
      {/* Top Banner indicating demonstration academic project with spring boot hub button */}
      <div className="bg-gradient-to-r from-slate-900 via-rose-950 to-slate-900 text-white text-xs py-2 px-4 border-b border-rose-900/40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold">BloodConnect Full-Stack System</span>
            <span className="hidden sm:inline text-slate-400">• Java 21, Spring Boot 3.2, Spring Security & MySQL 8</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsExplorerOpen(true)}
              className="bg-rose-600 hover:bg-rose-700 text-white font-extrabold px-2.5 py-1 rounded text-[11px] transition shadow-xs flex items-center gap-1"
            >
              🎓 Spring Boot & MySQL Hub
            </button>
          </div>
        </div>
      </div>

      {/* Primary Navigation Bar */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenExplorer={() => setIsExplorerOpen(true)}
      />

      {/* Main Routed Page Content */}
      <main className="flex-1">
        {activePage === 'index' && (
          <HomeView
            stats={stats}
            emergencyRequests={emergencyRequests}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'find-donor' && (
          <FindDonorView
            donors={donors}
          />
        )}

        {activePage === 'request-blood' && (
          <RequestBloodView
            existingRequests={bloodRequests}
            onRequestSubmitted={handleRequestSubmitted}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'register' && (
          <RegisterView
            onRegisterSuccess={handleRegisterSuccess}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'login' && (
          <LoginView
            onLoginSuccess={handleLoginSuccess}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'about' && (
          <AboutView />
        )}

        {activePage === 'donor-profile' && (
          <DonorProfileView
            currentUser={currentUser}
            donors={donors}
            emergencyRequests={emergencyRequests}
            onUpdateAvailability={handleUpdateAvailability}
            onRequestAccepted={handleRequestAccepted}
            setActivePage={setActivePage}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        setActivePage={setActivePage}
        onOpenExplorer={() => setIsExplorerOpen(true)}
      />

      {/* Java Spring Boot & MySQL Source & Architecture Modal */}
      <SpringBootExplorerModal
        isOpen={isExplorerOpen}
        onClose={() => setIsExplorerOpen(false)}
      />

    </div>
  );
}
