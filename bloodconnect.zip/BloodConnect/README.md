# 🩸 BloodConnect — Complete Full-Stack Blood Donation & Emergency Request Platform

An enterprise-grade, university-level full-stack web application connecting voluntary blood donors, patients, and hospital administrators in real-time. Built with **Java 21**, **Spring Boot 3.x**, **Spring Data JPA**, **Spring Security**, and **MySQL 8**.

---

## 🌟 Key Highlights & Architecture

- **Stateless RESTful Architecture**: Spring Boot 3.x backend exposing REST APIs with Spring Security + JWT authentication.
- **Relational Integrity**: MySQL 8 database schema with foreign keys, compound indexes, unique constraints, and cascade policies.
- **Donor Privacy Guard**: Donors' exact street addresses and direct contact numbers are safeguarded from unauthorized scraping.
- **Bi-directional Blood Compatibility Engine**: Automatic calculation of donor-recipient compatibility rules (e.g. O- universal donor, AB+ universal recipient).
- **Emergency Priority Queuing**: Visual and algorithmic priority ordering for life-threatening blood requests (Normal, Urgent, Emergency).
- **Zero-CORS Same-Origin Serving**: Frontend HTML5, CSS3, and Vanilla JavaScript assets served directly from Spring Boot's `src/main/resources/static/` folder.

---

## 🏗️ Technology Stack

| Layer | Technologies |
|---|---|
| **Backend** | Java 21, Spring Boot 3.2.5, Spring Web, Spring Data JPA, Hibernate |
| **Security** | Spring Security 6, JJWT (JSON Web Token), BCrypt Password Encoder |
| **Database** | MySQL 8.0+ (InnoDB Engine, utf8mb4 encoding) |
| **Validation** | Jakarta Bean Validation 3.0 (`@NotBlank`, `@Email`, `@Min`, `@Max`) |
| **Build Tool** | Apache Maven 3.9+ |
| **Frontend** | HTML5, CSS3, Vanilla JavaScript (ES6+), Fetch API |

---

## 📁 Project Directory Structure

```
BloodConnect/
├── pom.xml                                   # Maven dependencies & build plugins
├── README.md                                 # Full documentation & viva guide
├── database/
│   └── schema.sql                            # Complete MySQL 8 DDL & demo seed script
└── src/
    └── main/
        ├── java/com/bloodconnect/
        │   ├── BloodConnectApplication.java  # Main Spring Boot Application Runner
        │   ├── config/
        │   │   ├── SecurityConfig.java       # Spring Security 6 & JWT filter chain
        │   │   └── WebConfig.java            # Static resource handler configuration
        │   ├── entity/
        │   │   ├── User.java                 # User credentials, roles, timestamps
        │   │   ├── Donor.java                # Donor profile, blood type, privacy
        │   │   ├── BloodRequest.java         # Blood request tickets, urgency status
        │   │   ├── DonorRequestConnection.java # Donor response connection mapping
        │   │   ├── BloodGroup.java           # Enum with compatibility algorithms
        │   │   ├── UrgencyLevel.java         # NORMAL, URGENT, EMERGENCY
        │   │   ├── RequestStatus.java        # PENDING, ACCEPTED, FULFILLED, CANCELLED
        │   │   └── Role.java                 # ROLE_DONOR, ROLE_REQUESTER, ROLE_ADMIN
        │   ├── repository/
        │   │   ├── UserRepository.java
        │   │   ├── DonorRepository.java
        │   │   ├── BloodRequestRepository.java
        │   │   └── DonorRequestConnectionRepository.java
        │   ├── service/
        │   │   ├── UserService.java
        │   │   ├── DonorService.java
        │   │   ├── BloodRequestService.java
        │   │   └── StatsService.java
        │   ├── controller/
        │   │   ├── AuthController.java       # /api/auth/login
        │   │   ├── DonorController.java      # /api/donors/register, /api/donors/search
        │   │   ├── BloodRequestController.java # /api/requests
        │   │   └── StatsController.java      # /api/stats
        │   ├── dto/
        │   │   ├── LoginRequest.java
        │   │   ├── RegisterDonorRequest.java
        │   │   ├── BloodRequestDto.java
        │   │   ├── DonorSearchCriteria.java
        │   │   ├── AuthResponse.java
        │   │   └── StatsResponse.java
        │   ├── security/
        │   │   ├── JwtTokenProvider.java     # Token creation, parsing, validation
        │   │   ├── JwtAuthenticationFilter.java # Per-request Bearer token parser
        │   │   └── CustomUserDetailsService.java # UserDetailsService integration
        │   └── exception/
        │       ├── ResourceNotFoundException.java
        │       ├── BadRequestException.java
        │       └── GlobalExceptionHandler.java # Standardized JSON error response handler
        └── resources/
            ├── application.properties        # DB URLs, credentials, JPA configs
            └── static/                       # Frontend static files
                ├── index.html                # Homepage & live stats
                ├── find-donor.html           # Donor discovery & filtering
                ├── request-blood.html        # Emergency request ticket submission
                ├── register.html             # Donor registration with medical checks
                ├── login.html                # Multi-role authentication
                ├── about.html                # Mission, facts & compatibility matrix
                ├── donor-profile.html        # Personal donor dashboard & availability
                ├── css/
                │   └── style.css             # BloodConnect custom stylesheet
                └── js/
                    └── script.js             # Fetch API backend integration script
```

---

## 🚀 Getting Started

### 1. Prerequisites
- **Java Development Kit (JDK)**: Version 21 or higher (`java -version`)
- **Apache Maven**: Version 3.8+ (`mvn -version`)
- **MySQL Server**: Version 8.0+ (`mysql -V`)

### 2. Database Setup
1. Log into your MySQL server via terminal or MySQL Workbench:
   ```bash
   mysql -u root -p
   ```
2. Execute the included SQL script:
   ```sql
   source /path/to/BloodConnect/database/schema.sql;
   ```
   *This automatically creates `bloodconnect_db`, builds all foreign-keyed tables, and populates initial demonstration records.*

### 3. Application Configuration
Review `src/main/resources/application.properties` and verify your MySQL password:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/bloodconnect_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=root123  # <-- update to match your MySQL root password
```

### 4. Build and Run
From the root of the `BloodConnect` directory:
```bash
# Clean and compile
mvn clean install

# Run the Spring Boot application
mvn spring-boot:run
```

Once started, open your web browser and navigate to:
👉 **`http://localhost:8080`**

---

## 🔑 Demonstration Credentials

| Role | Email | Password |
|---|---|---|
| **Administrator** | `admin@bloodconnect.org` | `Password@123` |
| **Registered Donor** | `aarav.sharma@example.com` | `Password@123` |
| **Requester / Hospital** | `vikram.hospital@example.com` | `Password@123` |

---

## 📡 REST API Reference

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `POST` | `/api/auth/login` | Authenticate user and receive JWT token | No |
| `POST` | `/api/donors/register` | Register as voluntary blood donor | No |
| `GET` | `/api/donors/search` | Search donors by bloodGroup, city, availability, compatibility | No |
| `GET` | `/api/donors/{id}` | Retrieve individual donor profile | No |
| `PATCH`| `/api/donors/{id}/availability` | Toggle donor availability (AVAILABLE/UNAVAILABLE) | Yes |
| `POST` | `/api/requests` | Submit emergency blood request ticket | No |
| `GET` | `/api/requests` | Search/list blood requests (filtered by city/blood group) | No |
| `GET` | `/api/requests/emergency` | Retrieve top priority emergency requests | No |
| `GET` | `/api/stats` | Live platform metrics (donors, requests, fulfillments) | No |

---

## 🎓 College Viva & Examination Q&A

**Q1: Why did you choose Spring Boot for this platform?**  
*Answer:* Spring Boot provides enterprise-grade reliability, out-of-the-box support for Spring Data JPA, automated transaction management, built-in Bean Validation, and embedded web container support with zero XML boilerplate.

**Q2: How is donor privacy protected?**  
*Answer:* The `address` field in the `Donor` entity is tagged with `@JsonIgnore` and never serialized across public search API endpoints. Phone numbers are presented through a masked format to prevent mass automated scraping.

**Q3: How does the Blood Compatibility logic work?**  
*Answer:* In `BloodGroup.java`, the `getCompatibleDonorGroups()` method models the biological ABO and Rh antigen rules. For instance, when a patient requires `A+`, the engine fetches donors with `A+`, `A-`, `O+`, and `O-`.

**Q4: How does Spring Security handle authentication?**  
*Answer:* We use stateless JWT (JSON Web Tokens). When a user logs in, Spring Security authenticates credentials using BCrypt. Upon success, a signed JWT containing claims is returned. Clients include this token in the `Authorization: Bearer <token>` header, verified on each request by `JwtAuthenticationFilter`.
