-- ====================================================================
-- PROJECT: BloodConnect — Relational Database Schema (MySQL 8)
-- Description: Complete schema for Users, Donors, Requests, and Connections
-- Note: Includes indexes, foreign key constraints, and labeled demonstration records
-- ====================================================================

CREATE DATABASE IF NOT EXISTS bloodconnect_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bloodconnect_db;

-- 1. USERS TABLE
DROP TABLE IF EXISTS donor_request_connections;
DROP TABLE IF EXISTS blood_requests;
DROP TABLE IF EXISTS donors;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL DEFAULT 'ROLE_DONOR',
    account_status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- 2. DONORS TABLE (With protected contact and address fields)
CREATE TABLE donors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNIQUE,
    age INT NOT NULL CHECK (age >= 18 AND age <= 65),
    blood_group VARCHAR(6) NOT NULL,
    phone_number VARCHAR(25) NOT NULL,
    city VARCHAR(80) NOT NULL,
    address VARCHAR(255) NOT NULL COMMENT 'Protected: Accessible only by authenticated hospital admins or with donor consent',
    availability_status VARCHAR(32) NOT NULL DEFAULT 'AVAILABLE' COMMENT 'AVAILABLE, UNAVAILABLE, ON_COOLDOWN',
    last_donation_date DATE NULL,
    total_donations INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_donor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_donors_search (blood_group, city, availability_status),
    INDEX idx_donors_city (city),
    INDEX idx_donors_blood (blood_group)
) ENGINE=InnoDB;

-- 3. BLOOD REQUESTS TABLE
CREATE TABLE blood_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(120) NOT NULL,
    required_blood_group VARCHAR(6) NOT NULL,
    number_of_units INT NOT NULL DEFAULT 1 CHECK (number_of_units > 0 AND number_of_units <= 10),
    contact_number VARCHAR(25) NOT NULL,
    hospital_name VARCHAR(150) NOT NULL,
    hospital_location VARCHAR(120) NOT NULL,
    urgency VARCHAR(20) NOT NULL DEFAULT 'NORMAL' COMMENT 'NORMAL, URGENT, EMERGENCY',
    additional_message TEXT NULL,
    request_status VARCHAR(30) NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING, ACCEPTED, FULFILLED, CANCELLED',
    requester_id BIGINT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_request_user FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_requests_urgency_status (urgency, request_status),
    INDEX idx_requests_blood_city (required_blood_group, hospital_location),
    INDEX idx_requests_status (request_status)
) ENGINE=InnoDB;

-- 4. DONOR REQUEST CONNECTIONS (Tracks donor responses to blood requests)
CREATE TABLE donor_request_connections (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    blood_request_id BIGINT NOT NULL,
    donor_id BIGINT NOT NULL,
    connection_status VARCHAR(32) NOT NULL DEFAULT 'INITIATED' COMMENT 'INITIATED, ACCEPTED, DECLINED, COMPLETED',
    response_message VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_connection_request FOREIGN KEY (blood_request_id) REFERENCES blood_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_connection_donor FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    UNIQUE KEY uk_request_donor (blood_request_id, donor_id),
    INDEX idx_conn_donor (donor_id),
    INDEX idx_conn_request (blood_request_id)
) ENGINE=InnoDB;

-- ====================================================================
-- SEED DATA (CLEARLY LABELED AS DEMONSTRATION DATA)
-- Default password for demo users is: "Password@123"
-- BCrypt hash: $2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O
-- ====================================================================

-- 1. Seed Users (Demonstration Accounts)
INSERT INTO users (id, full_name, email, password_hash, role, account_status) VALUES
(1, 'System Administrator', 'admin@bloodconnect.org', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_ADMIN', 'ACTIVE'),
(2, 'Aarav Sharma', 'aarav.sharma@example.com', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_DONOR', 'ACTIVE'),
(3, 'Priya Patel', 'priya.patel@example.com', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_DONOR', 'ACTIVE'),
(4, 'Rahul Verma', 'rahul.verma@example.com', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_DONOR', 'ACTIVE'),
(5, 'Sneha Mukherjee', 'sneha.m@example.com', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_DONOR', 'ACTIVE'),
(6, 'Dr. Vikram Malhotra', 'vikram.hospital@example.com', '$2a$10$wE1M2rDkY2eCj0Kq6K5Qee4N/N69l/aV.3pQG6jN9O4D9l3WvB03O', 'ROLE_REQUESTER', 'ACTIVE');

-- 2. Seed Donors (Demonstration Donors)
INSERT INTO donors (id, user_id, age, blood_group, phone_number, city, address, availability_status, last_donation_date, total_donations) VALUES
(1, 2, 28, 'O+', '+91 98765 43210', 'Mumbai', 'Flat 402, Sea Breeze Apts, Bandra West', 'AVAILABLE', '2024-08-15', 5),
(2, 3, 24, 'A+', '+91 98234 56789', 'Delhi', 'B-12, Green Park Extension, New Delhi', 'AVAILABLE', '2024-09-02', 2),
(3, 4, 32, 'B+', '+91 97123 45678', 'Bangalore', 'Plot 88, Indiranagar 2nd Stage, Bangalore', 'AVAILABLE', '2024-07-20', 8),
(4, 5, 29, 'O-', '+91 96543 21098', 'Kolkata', '14/A, Salt Lake Sector 1, Kolkata', 'AVAILABLE', '2024-06-10', 4);

-- 3. Seed Blood Requests (Demonstration Requests)
INSERT INTO blood_requests (id, patient_name, required_blood_group, number_of_units, contact_number, hospital_name, hospital_location, urgency, additional_message, request_status, requester_id) VALUES
(1, 'Rohan Deshmukh', 'O+', 2, '+91 98111 22233', 'Lilavati Hospital & Research Centre', 'Mumbai', 'EMERGENCY', 'Urgent bypass surgery scheduled today at 4:00 PM. Critical requirement.', 'PENDING', 6),
(2, 'Meera Sen', 'A+', 1, '+91 98222 33344', 'AIIMS New Delhi', 'Delhi', 'URGENT', 'Platelet replacement for dengue fever treatment. Required within 24 hours.', 'PENDING', 6),
(3, 'Anand Kulkarni', 'B+', 3, '+91 98333 44455', 'Manipal Hospital', 'Bangalore', 'NORMAL', 'Scheduled orthopedic replacement surgery next Tuesday.', 'ACCEPTED', 6),
(4, 'Sunita Rao', 'AB+', 2, '+91 98444 55566', 'Apollo Gleneagles Hospital', 'Kolkata', 'NORMAL', 'Post-delivery postpartum recovery support. Request fulfilled successfully.', 'FULFILLED', 6);

-- 4. Seed Donor Request Connections (Demonstration Connections)
INSERT INTO donor_request_connections (id, blood_request_id, donor_id, connection_status, response_message) VALUES
(1, 3, 3, 'ACCEPTED', 'I am nearby and can reach Manipal Hospital by 10 AM.'),
(2, 4, 1, 'COMPLETED', 'Donation completed smoothly on Oct 18.');
