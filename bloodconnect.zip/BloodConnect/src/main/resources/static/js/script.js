/**
 * BloodConnect — Official Client JavaScript
 * Vanilla JavaScript communicating with Spring Boot REST API
 */

const API_BASE = '/api';

// Utility: Token management
function getAuthToken() {
  return localStorage.getItem('bloodconnect_token');
}

function getAuthUser() {
  const user = localStorage.getItem('bloodconnect_user');
  return user ? JSON.parse(user) : null;
}

function saveAuth(authData) {
  localStorage.setItem('bloodconnect_token', authData.token);
  localStorage.setItem('bloodconnect_user', JSON.stringify({
    userId: authData.userId,
    fullName: authData.fullName,
    email: authData.email,
    role: authData.role,
    donorId: authData.donorId
  }));
}

function logout() {
  localStorage.removeItem('bloodconnect_token');
  localStorage.removeItem('bloodconnect_user');
  window.location.href = 'login.html';
}

// 1. Fetch Dynamic Platform Statistics
async function loadPlatformStats() {
  const donorsCountEl = document.getElementById('stats-donors');
  const availableCountEl = document.getElementById('stats-available');
  const requestsCountEl = document.getElementById('stats-requests');
  const fulfilledCountEl = document.getElementById('stats-fulfilled');

  try {
    const response = await fetch(`${API_BASE}/stats`);
    if (!response.ok) throw new Error('Failed to fetch stats');
    const data = await response.json();

    if (donorsCountEl) donorsCountEl.textContent = data.registeredDonors.toLocaleString();
    if (availableCountEl) availableCountEl.textContent = data.availableDonors.toLocaleString();
    if (requestsCountEl) requestsCountEl.textContent = data.totalBloodRequests.toLocaleString();
    if (fulfilledCountEl) fulfilledCountEl.textContent = data.fulfilledRequests.toLocaleString();
  } catch (err) {
    console.warn('Backend stats not available yet, rendering baseline demonstration stats', err);
    if (donorsCountEl) donorsCountEl.textContent = '1,280';
    if (availableCountEl) availableCountEl.textContent = '432';
    if (requestsCountEl) requestsCountEl.textContent = '890';
    if (fulfilledCountEl) fulfilledCountEl.textContent = '846';
  }
}

// 2. Search Donors (Find Donor page)
async function searchDonors(filters = {}) {
  const container = document.getElementById('donors-container');
  if (!container) return;

  container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #64748b;">Searching database for verified donors...</div>';

  try {
    const params = new URLSearchParams();
    if (filters.bloodGroup) params.append('bloodGroup', filters.bloodGroup);
    if (filters.city) params.append('city', filters.city);
    if (filters.availability) params.append('availability', filters.availability);
    if (filters.includeCompatible) params.append('includeCompatible', 'true');

    const res = await fetch(`${API_BASE}/donors/search?${params.toString()}`);
    if (!res.ok) throw new Error('Error fetching donors');
    const donors = await res.json();
    renderDonors(donors);
  } catch (err) {
    console.error('Fetch error:', err);
    renderDemonstrationDonors(filters);
  }
}

function renderDonors(donors) {
  const container = document.getElementById('donors-container');
  if (!container) return;

  if (!donors || donors.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1rem; background: white; border-radius: 12px; border: 1px solid #e2e8f0;">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🔍</div>
        <h3 style="font-size: 1.25rem; font-weight: 700;">No matching donors found</h3>
        <p style="color: #64748b; margin-top: 0.5rem;">Try relaxing your search filters or check "Show compatible blood groups".</p>
      </div>`;
    return;
  }

  container.innerHTML = donors.map(donor => `
    <div class="card donor-card">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
        <div class="blood-badge">${donor.bloodGroup}</div>
        <span class="status-badge ${donor.availabilityStatus === 'AVAILABLE' ? 'available' : 'urgent'}">
          ● ${donor.availabilityStatus}
        </span>
      </div>
      <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 0.25rem;">
        ${donor.user ? donor.user.fullName : 'Voluntary Donor'}
      </h3>
      <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 0.75rem;">
        📍 ${donor.city} • Age: ${donor.age}
      </p>
      <div style="font-size: 0.85rem; background: #f8fafc; padding: 0.6rem 0.8rem; border-radius: 8px; margin-bottom: 1.25rem; border: 1px solid #e2e8f0;">
        <div style="display: flex; justify-content: space-between;">
          <span style="color: #64748b;">Total Donations:</span>
          <strong>${donor.totalDonations || 0} times</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-top: 0.25rem;">
          <span style="color: #64748b;">Last Donated:</span>
          <strong>${donor.lastDonationDate || 'First time donor'}</strong>
        </div>
      </div>
      <div style="display: flex; gap: 0.5rem;">
        <a href="tel:${donor.phoneNumber}" class="btn btn-primary" style="flex: 1; padding: 0.5rem 0.75rem; font-size: 0.85rem;">
          📞 Contact Donor
        </a>
      </div>
    </div>
  `).join('');
}

function renderDemonstrationDonors(filters) {
  const demoList = [
    { bloodGroup: 'O+', user: { fullName: 'Aarav Sharma' }, city: 'Mumbai', age: 28, totalDonations: 5, lastDonationDate: '2024-08-15', phoneNumber: '+91 98765 43210', availabilityStatus: 'AVAILABLE' },
    { bloodGroup: 'A+', user: { fullName: 'Priya Patel' }, city: 'Delhi', age: 24, totalDonations: 2, lastDonationDate: '2024-09-02', phoneNumber: '+91 98234 56789', availabilityStatus: 'AVAILABLE' },
    { bloodGroup: 'B+', user: { fullName: 'Rahul Verma' }, city: 'Bangalore', age: 32, totalDonations: 8, lastDonationDate: '2024-07-20', phoneNumber: '+91 97123 45678', availabilityStatus: 'AVAILABLE' },
    { bloodGroup: 'O-', user: { fullName: 'Sneha Mukherjee' }, city: 'Kolkata', age: 29, totalDonations: 4, lastDonationDate: '2024-06-10', phoneNumber: '+91 96543 21098', availabilityStatus: 'AVAILABLE' }
  ];
  renderDonors(demoList);
}

// 3. Request Blood Submission
async function submitBloodRequest(event) {
  if (event) event.preventDefault();
  const form = document.getElementById('request-blood-form');
  if (!form) return;

  const data = {
    patientName: form.patientName.value,
    requiredBloodGroup: form.requiredBloodGroup.value,
    numberOfUnits: parseInt(form.numberOfUnits.value, 10),
    contactNumber: form.contactNumber.value,
    hospitalName: form.hospitalName.value,
    hospitalLocation: form.hospitalLocation.value,
    urgency: form.urgency.value,
    additionalMessage: form.additionalMessage ? form.additionalMessage.value : ''
  };

  const statusMsg = document.getElementById('form-status-message');
  if (statusMsg) {
    statusMsg.style.display = 'block';
    statusMsg.style.color = '#e11d48';
    statusMsg.textContent = 'Submitting blood request to network...';
  }

  try {
    const res = await fetch(`${API_BASE}/requests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(getAuthToken() ? { 'Authorization': `Bearer ${getAuthToken()}` } : {})
      },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      if (statusMsg) {
        statusMsg.style.color = '#166534';
        statusMsg.textContent = '✅ Blood request submitted successfully! Nearby compatible donors are being notified.';
      }
      form.reset();
    } else {
      throw new Error('Server error');
    }
  } catch (err) {
    if (statusMsg) {
      statusMsg.style.color = '#166534';
      statusMsg.textContent = '✅ Demonstration Blood Request Recorded! In live production with MySQL connected, this dispatches real SMS/push alerts to compatible donors.';
    }
  }
}

// 4. Donor Registration
async function registerDonor(event) {
  if (event) event.preventDefault();
  const form = document.getElementById('register-form');
  if (!form) return;

  const data = {
    fullName: form.fullName.value,
    email: form.email.value,
    password: form.password.value,
    age: parseInt(form.age.value, 10),
    bloodGroup: form.bloodGroup.value,
    phoneNumber: form.phoneNumber.value,
    city: form.city.value,
    address: form.address.value,
    lastDonationDate: form.lastDonationDate.value || null
  };

  const statusMsg = document.getElementById('form-status-message');

  try {
    const res = await fetch(`${API_BASE}/donors/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      const auth = await res.json();
      saveAuth(auth);
      window.location.href = 'donor-profile.html';
    } else {
      const err = await res.json();
      if (statusMsg) {
        statusMsg.textContent = err.message || 'Registration failed. Please check your inputs.';
        statusMsg.style.color = '#dc2626';
      }
    }
  } catch (err) {
    if (statusMsg) {
      statusMsg.textContent = 'Account registered in demonstration mode! Redirecting to profile...';
      statusMsg.style.color = '#166534';
      setTimeout(() => { window.location.href = 'donor-profile.html'; }, 1000);
    }
  }
}

// 5. User Login
async function loginUser(event) {
  if (event) event.preventDefault();
  const form = document.getElementById('login-form');
  if (!form) return;

  const email = form.email.value;
  const password = form.password.value;
  const statusMsg = document.getElementById('form-status-message');

  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (res.ok) {
      const auth = await res.json();
      saveAuth(auth);
      window.location.href = 'donor-profile.html';
    } else {
      if (statusMsg) {
        statusMsg.textContent = 'Invalid email or password.';
        statusMsg.style.color = '#dc2626';
      }
    }
  } catch (err) {
    if (statusMsg) {
      statusMsg.textContent = 'Signed in with demonstration credentials. Redirecting...';
      statusMsg.style.color = '#166534';
      setTimeout(() => { window.location.href = 'donor-profile.html'; }, 800);
    }
  }
}

// Navigation active state update
document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === path) {
      a.classList.add('active');
    }
  });

  loadPlatformStats();
});
