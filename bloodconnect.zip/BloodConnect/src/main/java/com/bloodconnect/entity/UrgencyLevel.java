package com.bloodconnect.entity;

public enum UrgencyLevel {
    NORMAL,
    URGENT,
    EMERGENCY
}
