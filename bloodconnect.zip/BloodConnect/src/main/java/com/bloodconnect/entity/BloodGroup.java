package com.bloodconnect.entity;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum BloodGroup {
    A_POSITIVE("A+"),
    A_NEGATIVE("A-"),
    B_POSITIVE("B+"),
    B_NEGATIVE("B-"),
    AB_POSITIVE("AB+"),
    AB_NEGATIVE("AB-"),
    O_POSITIVE("O+"),
    O_NEGATIVE("O-");

    private final String label;

    BloodGroup(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static BloodGroup fromString(String text) {
        for (BloodGroup b : BloodGroup.values()) {
            if (b.label.equalsIgnoreCase(text) || b.name().equalsIgnoreCase(text)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unknown blood group: " + text);
    }

    /**
     * Determines which donor blood groups can give blood to a patient with this blood group.
     */
    public List<BloodGroup> getCompatibleDonorGroups() {
        return switch (this) {
            case A_POSITIVE -> Arrays.asList(A_POSITIVE, A_NEGATIVE, O_POSITIVE, O_NEGATIVE);
            case A_NEGATIVE -> Arrays.asList(A_NEGATIVE, O_NEGATIVE);
            case B_POSITIVE -> Arrays.asList(B_POSITIVE, B_NEGATIVE, O_POSITIVE, O_NEGATIVE);
            case B_NEGATIVE -> Arrays.asList(B_NEGATIVE, O_NEGATIVE);
            case AB_POSITIVE -> Arrays.asList(values()); // Universal Recipient
            case AB_NEGATIVE -> Arrays.asList(AB_NEGATIVE, A_NEGATIVE, B_NEGATIVE, O_NEGATIVE);
            case O_POSITIVE -> Arrays.asList(O_POSITIVE, O_NEGATIVE);
            case O_NEGATIVE -> Collections.singletonList(O_NEGATIVE); // Universal Donor only accepts O-
        };
    }
}
