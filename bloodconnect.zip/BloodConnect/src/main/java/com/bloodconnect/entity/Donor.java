package com.bloodconnect.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "donors")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @Min(value = 18, message = "Donor must be at least 18 years old")
    @Max(value = 65, message = "Donor cannot be older than 65 years")
    @Column(nullable = false)
    private Integer age;

    @NotBlank(message = "Blood group is required")
    @Column(nullable = false, length = 6)
    private String bloodGroup;

    @NotBlank(message = "Phone number is required")
    @Column(nullable = false, length = 25)
    private String phoneNumber;

    @NotBlank(message = "City is required")
    @Column(nullable = false, length = 80)
    private String city;

    /**
     * Address is strictly protected and hidden from anonymous/public requests.
     */
    @JsonIgnore
    @Column(nullable = false, length = 255)
    private String address;

    @Column(nullable = false, length = 32)
    @Builder.Default
    private String availabilityStatus = "AVAILABLE"; // AVAILABLE, UNAVAILABLE, ON_COOLDOWN

    private LocalDate lastDonationDate;

    @Column(nullable = false)
    @Builder.Default
    private Integer totalDonations = 0;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    /**
     * Helper to check if donor is eligible (at least 90 days since last donation)
     */
    @Transient
    public boolean isEligible() {
        if (!"AVAILABLE".equalsIgnoreCase(availabilityStatus)) {
            return false;
        }
        if (lastDonationDate == null) {
            return true;
        }
        return lastDonationDate.plusDays(90).isBefore(LocalDate.now()) ||
               lastDonationDate.plusDays(90).isEqual(LocalDate.now());
    }
}
