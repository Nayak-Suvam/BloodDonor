package com.bloodconnect.entity;

public enum Role {
    ROLE_DONOR,
    ROLE_REQUESTER,
    ROLE_ADMIN
}
