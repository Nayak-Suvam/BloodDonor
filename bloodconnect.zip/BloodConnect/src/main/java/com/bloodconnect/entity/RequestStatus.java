package com.bloodconnect.entity;

public enum RequestStatus {
    PENDING,
    ACCEPTED,
    FULFILLED,
    CANCELLED
}
