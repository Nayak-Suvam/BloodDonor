package com.bloodconnect.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "blood_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BloodRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Patient name is required")
    @Column(nullable = false, length = 120)
    private String patientName;

    @NotBlank(message = "Required blood group is required")
    @Column(nullable = false, length = 6)
    private String requiredBloodGroup;

    @Min(value = 1, message = "At least 1 unit of blood must be requested")
    @Max(value = 10, message = "Maximum 10 units can be requested at one time")
    @Column(nullable = false)
    private Integer numberOfUnits;

    @NotBlank(message = "Contact number is required")
    @Column(nullable = false, length = 25)
    private String contactNumber;

    @NotBlank(message = "Hospital name is required")
    @Column(nullable = false, length = 150)
    private String hospitalName;

    @NotBlank(message = "Hospital location or city is required")
    @Column(nullable = false, length = 120)
    private String hospitalLocation;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private UrgencyLevel urgency = UrgencyLevel.NORMAL;

    @Column(columnDefinition = "TEXT")
    private String additionalMessage;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private RequestStatus requestStatus = RequestStatus.PENDING;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requester_id")
    private User requester;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
