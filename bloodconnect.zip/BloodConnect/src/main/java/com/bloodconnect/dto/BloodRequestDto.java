package com.bloodconnect.dto;

import com.bloodconnect.entity.UrgencyLevel;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BloodRequestDto {
    private Long id;

    @NotBlank(message = "Patient name is required")
    private String patientName;

    @NotBlank(message = "Blood group is required")
    private String requiredBloodGroup;

    @NotNull(message = "Number of units is required")
    @Min(value = 1, message = "At least 1 unit is required")
    @Max(value = 10, message = "Maximum 10 units per request")
    private Integer numberOfUnits;

    @NotBlank(message = "Contact number is required")
    private String contactNumber;

    @NotBlank(message = "Hospital name is required")
    private String hospitalName;

    @NotBlank(message = "Hospital location or city is required")
    private String hospitalLocation;

    private UrgencyLevel urgency = UrgencyLevel.NORMAL;

    private String additionalMessage;

    private String requestStatus;
}
