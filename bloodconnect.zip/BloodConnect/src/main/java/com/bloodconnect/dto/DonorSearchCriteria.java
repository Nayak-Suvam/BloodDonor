package com.bloodconnect.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DonorSearchCriteria {
    private String bloodGroup;
    private String city;
    private String availability;
    private Boolean includeCompatible;
}
