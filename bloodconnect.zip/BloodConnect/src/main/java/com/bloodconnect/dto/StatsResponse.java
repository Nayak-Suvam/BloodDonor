package com.bloodconnect.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StatsResponse {
    private long registeredDonors;
    private long availableDonors;
    private long totalBloodRequests;
    private long fulfilledRequests;
    private double fulfillmentRatePercentage;
}
