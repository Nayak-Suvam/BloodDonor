package com.bloodconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * BloodConnect — Blood Donor Discovery & Blood Request Management Platform
 * Main Spring Boot Application Entry Point
 */
@SpringBootApplication
public class BloodConnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BloodConnectApplication.class, args);
        System.out.println("=================================================");
        System.out.println("🩸 BloodConnect Platform Started Successfully!");
        System.out.println("🌍 Access the web application at: http://localhost:8080");
        System.out.println("=================================================");
    }
}
