package com.bloodconnect.repository;

import com.bloodconnect.entity.DonorRequestConnection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DonorRequestConnectionRepository extends JpaRepository<DonorRequestConnection, Long> {
    List<DonorRequestConnection> findByDonorId(Long donorId);
    List<DonorRequestConnection> findByBloodRequestId(Long bloodRequestId);
    Optional<DonorRequestConnection> findByBloodRequestIdAndDonorId(Long bloodRequestId, Long donorId);
}
