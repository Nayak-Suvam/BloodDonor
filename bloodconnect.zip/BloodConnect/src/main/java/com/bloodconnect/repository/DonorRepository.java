package com.bloodconnect.repository;

import com.bloodconnect.entity.Donor;
import com.bloodconnect.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DonorRepository extends JpaRepository<Donor, Long> {
    
    Optional<Donor> findByUser(User user);

    List<Donor> findByAvailabilityStatus(String availabilityStatus);

    @Query("SELECT d FROM Donor d WHERE " +
           "(:bloodGroup IS NULL OR d.bloodGroup = :bloodGroup) AND " +
           "(:city IS NULL OR LOWER(d.city) LIKE LOWER(CONCAT('%', :city, '%'))) AND " +
           "(:availability IS NULL OR d.availabilityStatus = :availability)")
    List<Donor> searchDonors(
        @Param("bloodGroup") String bloodGroup,
        @Param("city") String city,
        @Param("availability") String availability
    );

    @Query("SELECT d FROM Donor d WHERE d.bloodGroup IN :compatibleGroups AND " +
           "(:city IS NULL OR LOWER(d.city) LIKE LOWER(CONCAT('%', :city, '%'))) AND " +
           "d.availabilityStatus = 'AVAILABLE'")
    List<Donor> findCompatibleDonors(
        @Param("compatibleGroups") List<String> compatibleGroups,
        @Param("city") String city
    );

    long countByAvailabilityStatus(String availabilityStatus);
}
