package com.bloodconnect.repository;

import com.bloodconnect.entity.BloodRequest;
import com.bloodconnect.entity.RequestStatus;
import com.bloodconnect.entity.UrgencyLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {

    List<BloodRequest> findByRequestStatusOrderByCreatedAtDesc(RequestStatus requestStatus);

    List<BloodRequest> findByUrgencyOrderByCreatedAtDesc(UrgencyLevel urgency);

    @Query("SELECT r FROM BloodRequest r WHERE " +
           "(:bloodGroup IS NULL OR r.requiredBloodGroup = :bloodGroup) AND " +
           "(:city IS NULL OR LOWER(r.hospitalLocation) LIKE LOWER(CONCAT('%', :city, '%'))) AND " +
           "(:status IS NULL OR r.requestStatus = :status) " +
           "ORDER BY CASE WHEN r.urgency = 'EMERGENCY' THEN 1 WHEN r.urgency = 'URGENT' THEN 2 ELSE 3 END, r.createdAt DESC")
    List<BloodRequest> searchRequests(
        @Param("bloodGroup") String bloodGroup,
        @Param("city") String city,
        @Param("status") RequestStatus status
    );

    long countByRequestStatus(RequestStatus requestStatus);
}
