package com.bloodconnect.service;

import com.bloodconnect.dto.BloodRequestDto;
import com.bloodconnect.entity.BloodRequest;
import com.bloodconnect.entity.RequestStatus;
import com.bloodconnect.entity.UrgencyLevel;
import com.bloodconnect.entity.User;
import com.bloodconnect.exception.ResourceNotFoundException;
import com.bloodconnect.repository.BloodRequestRepository;
import com.bloodconnect.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BloodRequestService {

    private final BloodRequestRepository bloodRequestRepository;
    private final UserRepository userRepository;

    @Transactional
    public BloodRequest createRequest(BloodRequestDto dto, String authenticatedEmail) {
        User requester = null;
        if (authenticatedEmail != null && !authenticatedEmail.isBlank()) {
            requester = userRepository.findByEmail(authenticatedEmail).orElse(null);
        }

        BloodRequest request = BloodRequest.builder()
                .patientName(dto.getPatientName().trim())
                .requiredBloodGroup(dto.getRequiredBloodGroup().trim().toUpperCase())
                .numberOfUnits(dto.getNumberOfUnits())
                .contactNumber(dto.getContactNumber().trim())
                .hospitalName(dto.getHospitalName().trim())
                .hospitalLocation(dto.getHospitalLocation().trim())
                .urgency(dto.getUrgency() != null ? dto.getUrgency() : UrgencyLevel.NORMAL)
                .additionalMessage(dto.getAdditionalMessage())
                .requestStatus(RequestStatus.PENDING)
                .requester(requester)
                .build();

        return bloodRequestRepository.save(request);
    }

    @Transactional(readOnly = true)
    public List<BloodRequest> getAllRequests(String bloodGroup, String city, RequestStatus status) {
        return bloodRequestRepository.searchRequests(
                (bloodGroup != null && !bloodGroup.isBlank()) ? bloodGroup.trim().toUpperCase() : null,
                (city != null && !city.isBlank()) ? city.trim() : null,
                status
        );
    }

    @Transactional(readOnly = true)
    public List<BloodRequest> getEmergencyRequests() {
        return bloodRequestRepository.findByUrgencyOrderByCreatedAtDesc(UrgencyLevel.EMERGENCY);
    }

    @Transactional
    public BloodRequest updateStatus(Long id, RequestStatus newStatus) {
        BloodRequest request = bloodRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Blood request not found with id: " + id));
        request.setRequestStatus(newStatus);
        return bloodRequestRepository.save(request);
    }
}
