package com.bloodconnect.service;

import com.bloodconnect.dto.StatsResponse;
import com.bloodconnect.entity.RequestStatus;
import com.bloodconnect.repository.BloodRequestRepository;
import com.bloodconnect.repository.DonorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class StatsService {

    private final DonorRepository donorRepository;
    private final BloodRequestRepository bloodRequestRepository;

    @Transactional(readOnly = true)
    public StatsResponse getPlatformStats() {
        long registeredDonors = donorRepository.count();
        long availableDonors = donorRepository.countByAvailabilityStatus("AVAILABLE");
        long totalBloodRequests = bloodRequestRepository.count();
        long fulfilledRequests = bloodRequestRepository.countByRequestStatus(RequestStatus.FULFILLED);

        double fulfillmentRate = totalBloodRequests > 0
                ? ((double) fulfilledRequests / totalBloodRequests) * 100.0
                : 95.0;

        return StatsResponse.builder()
                .registeredDonors(registeredDonors)
                .availableDonors(availableDonors)
                .totalBloodRequests(totalBloodRequests)
                .fulfilledRequests(fulfilledRequests)
                .fulfillmentRatePercentage(Math.round(fulfillmentRate * 10.0) / 10.0)
                .build();
    }
}
