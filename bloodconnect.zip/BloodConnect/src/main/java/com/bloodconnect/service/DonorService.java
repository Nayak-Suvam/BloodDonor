package com.bloodconnect.service;

import com.bloodconnect.dto.AuthResponse;
import com.bloodconnect.dto.DonorSearchCriteria;
import com.bloodconnect.dto.RegisterDonorRequest;
import com.bloodconnect.entity.BloodGroup;
import com.bloodconnect.entity.Donor;
import com.bloodconnect.entity.Role;
import com.bloodconnect.entity.User;
import com.bloodconnect.exception.BadRequestException;
import com.bloodconnect.exception.ResourceNotFoundException;
import com.bloodconnect.repository.DonorRepository;
import com.bloodconnect.repository.UserRepository;
import com.bloodconnect.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DonorService {

    private final DonorRepository donorRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    @Transactional
    public AuthResponse registerDonor(RegisterDonorRequest request) {
        String email = request.getEmail().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new BadRequestException("An account with email " + email + " already exists");
        }

        // Validate Blood Group
        BloodGroup.fromString(request.getBloodGroup());

        // Create User entity
        User user = User.builder()
                .fullName(request.getFullName().trim())
                .email(email)
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .role(Role.ROLE_DONOR)
                .accountStatus("ACTIVE")
                .build();
        user = userRepository.save(user);

        // Create Donor entity
        Donor donor = Donor.builder()
                .user(user)
                .age(request.getAge())
                .bloodGroup(request.getBloodGroup().toUpperCase())
                .phoneNumber(request.getPhoneNumber().trim())
                .city(request.getCity().trim())
                .address(request.getAddress().trim()) // Stored securely
                .availabilityStatus("AVAILABLE")
                .lastDonationDate(request.getLastDonationDate())
                .totalDonations(0)
                .build();
        donor = donorRepository.save(donor);

        // Generate JWT token for seamless auto-login
        String token = jwtTokenProvider.generateToken(
                new UsernamePasswordAuthenticationToken(
                        user.getEmail(),
                        null,
                        Collections.singletonList(new SimpleGrantedAuthority(user.getRole().name()))
                )
        );

        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .userId(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .donorId(donor.getId())
                .build();
    }

    @Transactional(readOnly = true)
    public List<Donor> searchDonors(DonorSearchCriteria criteria) {
        String bloodGroup = (criteria.getBloodGroup() != null && !criteria.getBloodGroup().isBlank())
                ? criteria.getBloodGroup().trim().toUpperCase() : null;
        String city = (criteria.getCity() != null && !criteria.getCity().isBlank())
                ? criteria.getCity().trim() : null;
        String availability = (criteria.getAvailability() != null && !criteria.getAvailability().isBlank())
                ? criteria.getAvailability().trim().toUpperCase() : null;

        // If compatibility search is requested
        if (Boolean.TRUE.equals(criteria.getIncludeCompatible()) && bloodGroup != null) {
            try {
                BloodGroup bg = BloodGroup.fromString(bloodGroup);
                List<String> compatibleGroups = bg.getCompatibleDonorGroups().stream()
                        .map(BloodGroup::getLabel)
                        .collect(Collectors.toList());
                return donorRepository.findCompatibleDonors(compatibleGroups, city);
            } catch (Exception ignored) {
                // fallback to regular search
            }
        }

        return donorRepository.searchDonors(bloodGroup, city, availability);
    }

    @Transactional(readOnly = true)
    public Donor getDonorById(Long id) {
        return donorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Donor not found with ID: " + id));
    }

    @Transactional
    public Donor updateAvailability(Long donorId, String status) {
        Donor donor = getDonorById(donorId);
        donor.setAvailabilityStatus(status.toUpperCase());
        return donorRepository.save(donor);
    }
}
