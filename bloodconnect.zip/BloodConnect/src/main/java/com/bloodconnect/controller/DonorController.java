package com.bloodconnect.controller;

import com.bloodconnect.dto.AuthResponse;
import com.bloodconnect.dto.DonorSearchCriteria;
import com.bloodconnect.dto.RegisterDonorRequest;
import com.bloodconnect.entity.Donor;
import com.bloodconnect.service.DonorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/donors")
@RequiredArgsConstructor
public class DonorController {

    private final DonorService donorService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registerDonor(@Valid @RequestBody RegisterDonorRequest request) {
        AuthResponse response = donorService.registerDonor(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Donor>> searchDonors(
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String availability,
            @RequestParam(required = false, defaultValue = "false") Boolean includeCompatible
    ) {
        DonorSearchCriteria criteria = DonorSearchCriteria.builder()
                .bloodGroup(bloodGroup)
                .city(city)
                .availability(availability)
                .includeCompatible(includeCompatible)
                .build();
        List<Donor> donors = donorService.searchDonors(criteria);
        return ResponseEntity.ok(donors);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Donor> getDonorProfile(@PathVariable Long id) {
        return ResponseEntity.ok(donorService.getDonorById(id));
    }

    @PatchMapping("/{id}/availability")
    public ResponseEntity<Donor> updateAvailability(
            @PathVariable Long id,
            @RequestBody Map<String, String> payload
    ) {
        String status = payload.get("status");
        return ResponseEntity.ok(donorService.updateAvailability(id, status));
    }
}
