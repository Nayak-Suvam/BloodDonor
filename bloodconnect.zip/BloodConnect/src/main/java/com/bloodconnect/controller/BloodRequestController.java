package com.bloodconnect.controller;

import com.bloodconnect.dto.BloodRequestDto;
import com.bloodconnect.entity.BloodRequest;
import com.bloodconnect.entity.RequestStatus;
import com.bloodconnect.service.BloodRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
public class BloodRequestController {

    private final BloodRequestService bloodRequestService;

    @PostMapping
    public ResponseEntity<BloodRequest> createRequest(
            @Valid @RequestBody BloodRequestDto dto,
            Authentication authentication
    ) {
        String userEmail = (authentication != null) ? authentication.getName() : null;
        BloodRequest created = bloodRequestService.createRequest(dto, userEmail);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<BloodRequest>> getRequests(
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) RequestStatus status
    ) {
        return ResponseEntity.ok(bloodRequestService.getAllRequests(bloodGroup, city, status));
    }

    @GetMapping("/emergency")
    public ResponseEntity<List<BloodRequest>> getEmergencyRequests() {
        return ResponseEntity.ok(bloodRequestService.getEmergencyRequests());
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<BloodRequest> updateStatus(
            @PathVariable Long id,
            @RequestParam RequestStatus status
    ) {
        return ResponseEntity.ok(bloodRequestService.updateStatus(id, status));
    }
}
